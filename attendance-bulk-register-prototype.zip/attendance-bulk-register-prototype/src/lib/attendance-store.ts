import { useSyncExternalStore } from "react";

// Prototype data layer: seed registers plus anything added by uploading the
// dummy templates. Persisted to localStorage so it survives navigation/reloads.

export type Register = {
  id: string;
  name: string;
  users: number;
  boundary: string;
  frequency: string;
  officer: string;
  /** Deepest boundary and its code, for registers created from the template. */
  boundaryName?: string;
  boundaryCode?: string;
};

export type RegisterUser = {
  id: string;
  registerId: string;
  name: string;
  workerId: string;
  role: string;
  boundary: string;
  teamCode: string;
  status: "Active" | "Inactive";
};

export const SEED_REGISTERS: Register[] = [
  { id: "r-1", name: "BILL 16273673", users: 0, boundary: "State, LGA, Ward, Settlement", frequency: "Once", officer: "Anita Sharma" },
  { id: "r-2", name: "BILL 16273674", users: 0, boundary: "State, LGA, Ward", frequency: "Twice", officer: "Rahul Verma" },
  { id: "r-3", name: "BILL 16273675", users: 0, boundary: "State, LGA", frequency: "Once", officer: "Anita Sharma" },
  { id: "r-4", name: "BILL 16273676", users: 12, boundary: "State, LGA, Ward", frequency: "Twice", officer: "Meera Iyer" },
  { id: "r-5", name: "BILL 16273677", users: 43, boundary: "State, LGA, Ward, Settlement", frequency: "Once", officer: "Rahul Verma" },
];

export type AuditEntry = {
  id: string;
  action: string;
  /** Register name, or "" for campaign-level actions such as template downloads. */
  register: string;
  details: string;
  user: string;
  role: string;
  /** ISO timestamp. */
  at: string;
};

/** The signed-in user; every action taken in the prototype is logged against them. */
export const CURRENT_USER = { name: "Aisha Bello", role: "Campaign Supervisor" };

type State = {
  uploadedRegisters: Register[];
  deletedIds: string[];
  users: RegisterUser[];
  /** Registers added by the most recent register-template upload. */
  latestIds: string[];
  /** Registers picked on "Select attendance registers to map users". */
  mappingIds: string[];
  /** Frequency chosen on "Customize your Attendance Register Template". */
  templateFrequency: string | null;
  /** Audit entries recorded in this browser, newest first. */
  auditLog: AuditEntry[];
};

const STORAGE_KEY = "attendancePrototypeData";

const EMPTY: State = {
  uploadedRegisters: [],
  deletedIds: [],
  users: [],
  latestIds: [],
  mappingIds: [],
  templateFrequency: null,
  auditLog: [],
};

let state: State = EMPTY;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) state = { ...EMPTY, ...JSON.parse(raw) };
  } catch {
    // ignore storage errors
  }
}

function update(patch: Partial<State>) {
  load();
  state = { ...state, ...patch };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore storage errors
  }
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function getSnapshot() {
  load();
  return state;
}

export function useAttendanceStore() {
  // The server snapshot is always empty so SSR and hydration match.
  return useSyncExternalStore(subscribe, getSnapshot, () => EMPTY);
}

export function getAttendanceState() {
  return getSnapshot();
}

/** All visible registers, with user counts that include uploaded mappings. */
export function selectRegisters(s: State): Register[] {
  const deleted = new Set(s.deletedIds);
  return [...s.uploadedRegisters, ...SEED_REGISTERS]
    .filter((r) => !deleted.has(r.id))
    .map((r) => ({ ...r, users: r.users + s.users.filter((u) => u.registerId === r.id).length }));
}

let auditSeq = 0;

export const attendanceActions = {
  /** Records audit entries for actions taken by the signed-in user. */
  log(entries: { action: string; register?: string; details: string }[]) {
    if (!entries.length) return;
    const at = new Date().toISOString();
    const logged = entries.map((e) => ({
      id: `al-${Date.now().toString(36)}-${auditSeq++}`,
      action: e.action,
      register: e.register ?? "",
      details: e.details,
      user: CURRENT_USER.name,
      role: CURRENT_USER.role,
      at,
    }));
    // A batch shares a timestamp; keep it in the order the rows were processed.
    update({ auditLog: [...logged, ...getSnapshot().auditLog] });
  },

  setTemplateFrequency(frequency: string | null) {
    update({ templateFrequency: frequency });
  },

  /**
   * Adds uploaded registers; a register with the same name is replaced, so re-uploads don't
   * duplicate. Returns which registers were created and which already existed.
   */
  addRegisters(rows: Omit<Register, "id" | "users">[]) {
    const current = getSnapshot();
    const all = selectRegisters(current);
    const uploaded = [...current.uploadedRegisters];
    const added: Register[] = [];
    const latestIds: string[] = [];
    const created = new Set<string>();
    let nextId = Math.max(0, ...[...uploaded, ...SEED_REGISTERS].map((r) => Number(r.id.slice(2)) || 0)) + 1;
    for (const row of rows) {
      const repeat = added.find((r) => r.name === row.name);
      if (repeat) {
        Object.assign(repeat, row);
        continue;
      }
      const existing = all.find((r) => r.name === row.name);
      if (existing && uploaded.some((r) => r.id === existing.id)) {
        const i = uploaded.findIndex((r) => r.id === existing.id);
        uploaded[i] = { ...(uploaded[i] as Register), ...row };
        latestIds.push(existing.id);
      } else if (existing) {
        latestIds.push(existing.id);
      } else {
        const id = `r-${nextId++}`;
        added.push({ ...row, id, users: 0 });
        latestIds.push(id);
        created.add(id);
      }
    }
    // Newest uploads first, keeping the file's row order.
    update({ uploadedRegisters: [...added, ...uploaded], latestIds });
    return latestIds.map((id) => ({ id, created: created.has(id) }));
  },

  deleteRegisters(ids: string[]) {
    const current = getSnapshot();
    const remove = new Set(ids);
    const removed = selectRegisters(current).filter((r) => remove.has(r.id));
    const seedIds = new Set(SEED_REGISTERS.map((r) => r.id));
    update({
      uploadedRegisters: current.uploadedRegisters.filter((r) => !remove.has(r.id)),
      deletedIds: [...current.deletedIds, ...ids.filter((id) => seedIds.has(id))],
      users: current.users.filter((u) => !remove.has(u.registerId)),
    });
    attendanceActions.log(
      removed.map((r) => ({
        action: "Register Deleted",
        register: r.name,
        details: `Register deleted from Manage Register${r.users ? ` with ${r.users} mapped ${r.users === 1 ? "user" : "users"}` : ""}`,
      })),
    );
  },

  setMappingRegisters(ids: string[]) {
    update({ mappingIds: ids });
  },

  /** Adds mapped users; a user with the same worker ID in the same register is replaced. */
  addUsers(rows: Omit<RegisterUser, "id">[]) {
    const current = getSnapshot();
    const key = (u: { registerId: string; workerId: string }) => `${u.registerId}|${u.workerId}`;
    const incoming = new Set(rows.map(key));
    const kept = current.users.filter((u) => !incoming.has(key(u)));
    const added = rows.map((u, i) => ({ ...u, id: `u-${Date.now().toString(36)}-${i}` }));
    update({ users: [...kept, ...added] });
  },
};
