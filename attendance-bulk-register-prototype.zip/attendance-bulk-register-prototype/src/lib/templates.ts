import {
  attendanceActions,
  getAttendanceState,
  selectRegisters,
  type Register,
  type RegisterUser,
} from "./attendance-store";
import type { Sheet, SheetData } from "write-excel-file/browser";

// Dummy .xlsx templates for the prototype. They mirror the HCM admin console
// templates (Attendance Register Template / Attendee Template) sheet-for-sheet
// and column-for-column, minus the Event Type column. Each data sheet has a
// hidden row of column codes, a visible row of labels, then data from row 3.
// Downloads come pre-filled with sample data; uploading the same file adds
// that data to the app.

export type Column = { code: string; label: string; width?: number; hidden?: boolean; wrap?: boolean };

/* ---------- Column definitions (from the reference templates) ---------- */

const BOUNDARY_COLUMNS: Column[] = [
  { code: "NIGERIA_COUNTRY", label: "Country", width: 50 },
  { code: "NIGERIA_PROVINCE", label: "Province", width: 25 },
  { code: "NIGERIA_DISTRICT", label: "District", width: 25 },
  { code: "NIGERIA_ADMINISTRATIVEPOST", label: "Administrative Post", width: 25 },
  { code: "NIGERIA_LOCALITY", label: "Locality", width: 30 },
  { code: "NIGERIA_VILLAGE", label: "Village", width: 25 },
];

const BOUNDARY_CODE = "HCM_ADMIN_CONSOLE_BOUNDARY_CODE";
const REGISTER_ID = "HCM_ATTENDANCE_REGISTER_ID";
const SESSIONS = "HCM_ATTENDANCE_REGISTER_SESSIONS";
const ROW_ID = "HCM_ADMIN_CONSOLE____ROW_ID";

const REGISTER_COLUMNS: Column[] = [
  ...BOUNDARY_COLUMNS,
  { code: BOUNDARY_CODE, label: "Service Boundary Code", width: 30, hidden: true },
  { code: REGISTER_ID, label: "Register ID", width: 40 },
  { code: SESSIONS, label: "Sessions", width: 20 },
];

const BOUNDARY_DATA_COLUMNS: Column[] = [
  ...BOUNDARY_COLUMNS,
  { code: BOUNDARY_CODE, label: "Service Boundary Code", width: 80, hidden: true },
  { code: ROW_ID, label: "", width: 8, hidden: true },
];

const USER = {
  workerId: "HCM_ADMIN_CONSOLE_USER_WORKER_ID",
  name: "HCM_ADMIN_CONSOLE_USER_NAME",
  username: "UserName",
  roles: [1, 2, 3, 4, 5].map((n) => `HCM_ADMIN_CONSOLE_USER_ROLE_MULTISELECT_${n}`),
  boundary: "HCM_ADMIN_CONSOLE_BOUNDARY_NAME",
  boundaryCode: "HCM_ADMIN_CONSOLE_BOUNDARY_CODE_MANDATORY",
  enrollment: "HCM_ATTENDANCE_ATTENDEE_ENROLLMENT_DATE",
  deenrollment: "HCM_ATTENDANCE_ATTENDEE_DEENROLLMENT_DATE",
  teamCode: "HCM_ATTENDANCE_ATTENDEE_TEAM_CODE",
};

const ATTENDEE_COLUMNS = (withTeamCode: boolean): Column[] => [
  { code: USER.workerId, label: "User ID", width: 30 },
  { code: USER.name, label: "Name", width: 25 },
  { code: USER.username, label: "Username", width: 20 },
  ...USER.roles.map((code, i) => ({ code, label: `User Role ${i + 1}`, width: i === 0 ? 50 : 20 })),
  { code: USER.boundary, label: "Boundary", width: 25 },
  { code: USER.boundaryCode, label: "Boundary Code", width: 64, hidden: true },
  { code: REGISTER_ID, label: "Register ID", width: 64 },
  { code: USER.enrollment, label: "Enrollment Date", width: 20 },
  { code: USER.deenrollment, label: "De-enrollment Date", width: 20 },
  ...(withTeamCode ? [{ code: USER.teamCode, label: "Team Code", width: 15 }] : []),
  { code: ROW_ID, label: "", width: 8, hidden: true },
];

const ATTENDEE_SHEETS = [
  { name: "Frontline Workers", teamCode: true, perRegister: 3, roles: ["DISTRIBUTOR", "FIELD_SUPPORT"] },
  { name: "Attendance Markers", teamCode: false, perRegister: 1, roles: ["WAREHOUSE_MANAGER", "TEAM_SUPERVISOR"] },
  { name: "Attendance Approvers", teamCode: false, perRegister: 1, roles: ["CAMPAIGN_SUPERVISOR"] },
];

const ROLE_OPTIONS = [
  "DISTRIBUTOR",
  "HEALTH_FACILITY_WORKER",
  "WAREHOUSE_MANAGER",
  "NATIONAL_SUPERVISOR",
  "DISTRICT_SUPERVISOR",
  "TEAM_SUPERVISOR",
  "PROVINCIAL_SUPERVISOR",
  "DASHBOARD_VIEWER",
  "PROXIMITY_SUPERVISOR",
  "CAMPAIGN_SUPERVISOR",
  "PAYMENT_EDITOR",
  "PAYMENT_REVIEWER",
  "PAYMENT_APPROVER",
  "FIELD_SUPPORT",
];

const INSTRUCTIONS =
  "Instructions for filling the Attendance Register template:\n\n" +
  "1. Fill at least one boundary column for each row\n" +
  "2. The Register ID is auto-generated from the deepest boundary selected. You can edit it if needed.\n" +
  "3. Ensure all Register IDs are unique\n" +
  "4. Upload the completed file back to the system\n\n" +
  "Note: Projects must be created before generating attendance registers.";

/* ---------- Sample data ---------- */

const PARENT = ["Nigeria", "Plateau", "Kanam", "Dengi", "pl Dengi Primary Health Centre"];

const SAMPLE_VILLAGES = [
  { village: "ANGWAN GARKUWA", code: "NIGERIA_NI_09_14_18_01_64_ANGWAN_GARKUWA", registerId: "Angwan" },
  { village: "MAKABARTA A com 01", code: "NIGERIA_NI_09_14_18_01_63_MAKABARTA_A_COM_01", registerId: "Makabarta" },
  { village: "GENERAL HOSPITAL AREA", code: "NIGERIA_NI_09_14_18_01_62_GENERAL_HOSPITAL_AREA", registerId: "General Hospital" },
];

const SAMPLE_NAMES = [
  "Dwight", "Oscar", "Kevin", "Pam", "Michael", "Jim", "Angela", "Stanley", "Phyllis", "Andy",
  "Erin", "Toby", "Kelly", "Ryan", "Creed", "Meredith", "Darryl", "Holly", "Gabe", "Nellie",
];

const SAMPLE_ENROLLMENT_DATE = new Date(Date.UTC(2026, 7, 28));

/* ---------- Writing ---------- */

export type Cell = SheetData[number][number];

export type SheetSpec = {
  name: string;
  columns: Column[];
  rows: Cell[][];
  /** Optional list dropdowns, as in the reference templates. */
  lists?: { columns: string[]; options: string[] }[];
};

/** A generated template: what gets downloaded and what the preview shows. */
export type Workbook = {
  fileName: string;
  sheets: SheetSpec[];
  /** Audit entry recorded when the workbook is downloaded. */
  audit?: AuditInput;
};

type AuditInput = { action: string; register?: string; details: string };

export const colLetter = (i: number) => String.fromCharCode(65 + i);
const LAST_ROW = 5002;

function toSheet(spec: SheetSpec): Sheet<Blob> {
  const header = (text: string) => (text ? { value: text, fontWeight: "bold" as const } : null);
  // Long text (the instructions) wraps in a tall, regular-weight cell.
  const label = (c: Column) => (c.wrap ? { value: c.label, wrap: true, height: 170 } : header(c.label));
  return {
    sheet: spec.name,
    data: [spec.columns.map((c) => header(c.code)), spec.columns.map(label), ...spec.rows],
    columns: spec.columns.map((c) => ({ width: c.width ?? 20 })),
    stickyRowsCount: 2,
  };
}

/**
 * write-excel-file can't hide rows/columns or add dropdowns, so patch the sheet XML:
 * hide the code row (row 1) and hidden columns, and add list data validations.
 */
async function finalize(blob: Blob, specs: SheetSpec[]) {
  const { unzipSync, zipSync, strFromU8, strToU8 } = await import("fflate");
  const files = unzipSync(new Uint8Array(await blob.arrayBuffer()));
  specs.forEach((spec, i) => {
    const path = `xl/worksheets/sheet${i + 1}.xml`;
    const file = files[path];
    if (!file) return;
    let xml = strFromU8(file).replace('<row r="1">', '<row r="1" hidden="1">');
    spec.columns.forEach((c, ci) => {
      if (!c.hidden) return;
      xml = xml.replace(`<col min="${ci + 1}" max="${ci + 1}" `, `<col min="${ci + 1}" max="${ci + 1}" hidden="1" `);
    });
    if (spec.lists?.length) {
      const validations = spec.lists
        .map(({ columns, options }) => {
          const sqref = columns
            .map((code) => colLetter(spec.columns.findIndex((c) => c.code === code)))
            .map((l) => `${l}3:${l}${LAST_ROW}`)
            .join(" ");
          return `<dataValidation type="list" allowBlank="1" showErrorMessage="1" sqref="${sqref}"><formula1>"${options.join(",")}"</formula1></dataValidation>`;
        })
        .join("");
      xml = xml.replace("</sheetData>", `</sheetData><dataValidations count="${spec.lists.length}">${validations}</dataValidations>`);
    }
    files[path] = strToU8(xml);
  });
  return new Blob([zipSync(files)], { type: blob.type });
}

export async function downloadWorkbook({ fileName, sheets, audit }: Workbook) {
  const { default: writeXlsxFile } = await import("write-excel-file/browser");
  const blob = await finalize(await writeXlsxFile(sheets.map(toSheet)).toBlob(), sheets);
  saveBlob(blob, fileName);
  if (audit) attendanceActions.log([audit]);
}

function saveBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

/* ---------- Reading ---------- */

type TemplateRow = { get: (code: string) => string; label: (code: string) => string };

/** Returns data rows of every sheet that has all the `required` column codes in a header row. */
async function readSheets(file: File, required: string[]): Promise<TemplateRow[][]> {
  if (!/\.xlsx$/i.test(file.name)) {
    throw new Error("Please upload the .xlsx template downloaded from this page.");
  }
  const { default: readXlsxFile } = await import("read-excel-file/browser");
  let sheets: { sheet: string; data: unknown[][] }[];
  try {
    sheets = await readXlsxFile(file);
  } catch {
    throw new Error("This file couldn't be read. Please upload the downloaded .xlsx template.");
  }
  const text = (v: unknown) =>
    v == null ? "" : v instanceof Date ? v.toISOString().slice(0, 10) : String(v).trim();

  const result: TemplateRow[][] = [];
  for (const { data } of sheets) {
    const codeRow = data.findIndex((row) => required.every((c) => row.some((v) => text(v) === c)));
    if (codeRow < 0) continue;
    const codes = (data[codeRow] ?? []).map(text);
    const labels = (data[codeRow + 1] ?? []).map(text);
    const index = (code: string) => codes.indexOf(code);
    result.push(
      data
        .slice(codeRow + 2)
        .filter((cells) => cells.some((v) => text(v)))
        .map((cells) => ({
          get: (code) => (index(code) < 0 ? "" : text(cells[index(code)])),
          label: (code) => labels[index(code)] ?? code,
        })),
    );
  }
  if (!result.length) {
    throw new Error("This doesn't look like the template from this page. Please download it and try again.");
  }
  if (!result.some((rows) => rows.length)) {
    throw new Error("The template has no rows. Fill it in and upload it again.");
  }
  return result;
}

/* ---------- Attendance register template ---------- */

const sessionsFor = (frequency: string | null) => (frequency === "Twice a day" ? 2 : 1);

export function buildRegisterTemplate(): Workbook {
  const sessions = sessionsFor(getAttendanceState().templateFrequency);
  return {
    fileName: "Attendance_Register_Template.xlsx",
    audit: {
      action: "Template Downloaded",
      details: `Attendance register template downloaded · ${SAMPLE_VILLAGES.length} registers · ${sessions} ${sessions === 1 ? "session" : "sessions"} a day`,
    },
    sheets: [
      {
        name: "Instructions",
        // The instructions text sits in the label row, as in the reference template.
        columns: [
          { code: "HCM_ATTENDANCE_REGISTER_README_INSTRUCTIONS", label: INSTRUCTIONS, width: 100, wrap: true },
        ],
        rows: [],
      },
      {
        name: "Attendance Registers",
        columns: REGISTER_COLUMNS,
        rows: SAMPLE_VILLAGES.map((v) => [...PARENT, v.village, v.code, v.registerId, sessions]),
        lists: [{ columns: ["NIGERIA_COUNTRY"], options: ["Nigeria"] }],
      },
      {
        name: "Boundary Data",
        columns: BOUNDARY_DATA_COLUMNS,
        rows: SAMPLE_VILLAGES.map((v) => [...PARENT, v.village, v.code, crypto.randomUUID()]),
      },
    ],
  };
}

export const downloadRegisterTemplate = () => downloadWorkbook(buildRegisterTemplate());

/** Parses an uploaded register template and adds its registers. Returns how many were added. */
export async function uploadRegisterTemplate(file: File) {
  const [rows = []] = await readSheets(file, [REGISTER_ID, BOUNDARY_CODE]);
  const registers: Omit<Register, "id" | "users">[] = [];
  for (const row of rows) {
    const filled = BOUNDARY_COLUMNS.filter((c) => row.get(c.code));
    const deepest = filled[filled.length - 1];
    const name = row.get(REGISTER_ID) || row.get(BOUNDARY_CODE) || (deepest ? row.get(deepest.code) : "");
    if (!name) continue;
    const sessions = Number(row.get(SESSIONS)) || 1;
    registers.push({
      name,
      boundary: filled.map((c) => row.label(c.code)).join(", "),
      boundaryName: deepest ? row.get(deepest.code) : "",
      boundaryCode: row.get(BOUNDARY_CODE),
      frequency: sessions === 1 ? "Once" : sessions === 2 ? "Twice" : `${sessions} sessions`,
      officer: "",
    });
  }
  if (!registers.length) throw new Error("Every row needs a boundary or a Register ID.");
  const results = attendanceActions.addRegisters(registers);
  attendanceActions.log(
    results.map(({ created }, i) => {
      const r = registers[i]!;
      return created
        ? {
            action: "Register Generated",
            register: r.name,
            details: `Created from ${file.name} · Boundary: ${r.boundaryName || r.boundary} · Attendance ${r.frequency.toLowerCase()} a day`,
          }
        : {
            action: "Register Edited",
            register: r.name,
            details: `Updated from re-uploaded ${file.name}`,
          };
    }),
  );
  return registers.length;
}

/* ---------- User mapping (attendee) template ---------- */

function mappingRegisters() {
  const state = getAttendanceState();
  const all = selectRegisters(state);
  const picked = all.filter((r) => state.mappingIds.includes(r.id));
  return picked.length ? picked : all.slice(0, 2);
}

export function buildMappingTemplate(): Workbook {
  const registers = mappingRegisters();
  let n = 0;
  const specs: SheetSpec[] = ATTENDEE_SHEETS.map((sheet) => {
    const rows: Cell[][] = [];
    registers.forEach((r, ri) => {
      for (let i = 0; i < sheet.perRegister; i++, n++) {
        const name = SAMPLE_NAMES[n % SAMPLE_NAMES.length] ?? "User";
        const fallback = SAMPLE_VILLAGES[ri % SAMPLE_VILLAGES.length]!;
        rows.push([
          `WR-demo-${367900 + n}`,
          name,
          `${name}${Math.floor(n / SAMPLE_NAMES.length) + 1}`,
          sheet.roles[i % sheet.roles.length] ?? null,
          null,
          null,
          null,
          null,
          r.boundaryName || fallback.village,
          r.boundaryCode || fallback.code,
          r.name,
          { value: SAMPLE_ENROLLMENT_DATE, type: Date, format: "dd/mm/yyyy" },
          null,
          ...(sheet.teamCode ? [(i % 3) + 1] : []),
          crypto.randomUUID(),
        ]);
      }
    });
    return {
      name: sheet.name,
      columns: ATTENDEE_COLUMNS(sheet.teamCode),
      rows,
      lists: [{ columns: USER.roles, options: ROLE_OPTIONS }],
    };
  });
  return {
    fileName: "Attendee_Template.xlsx",
    sheets: specs,
    audit: {
      action: "Template Downloaded",
      details: `User mapping template downloaded for ${registers.map((r) => r.name).join(", ")}`,
    },
  };
}

export const downloadMappingTemplate = () => downloadWorkbook(buildMappingTemplate());

/** Parses an uploaded attendee template and maps users to matching registers. */
export async function uploadMappingTemplate(file: File) {
  const sheets = await readSheets(file, [USER.workerId, REGISTER_ID]);
  const byName = new Map(
    selectRegisters(getAttendanceState()).map((r) => [r.name.toLowerCase(), r]),
  );
  const users: Omit<RegisterUser, "id">[] = [];
  for (const row of sheets.flat()) {
    const register = byName.get(row.get(REGISTER_ID).toLowerCase());
    const name = row.get(USER.name);
    if (!register || !name) continue;
    users.push({
      registerId: register.id,
      name,
      workerId: row.get(USER.workerId) || name,
      role: USER.roles.map(row.get).filter(Boolean).join(", "),
      boundary: row.get(USER.boundary) || register.boundaryName || register.boundary,
      teamCode: row.get(USER.teamCode),
      status: "Active",
    });
  }
  if (!users.length) {
    throw new Error("No rows match an existing register. Check the Register ID column.");
  }
  attendanceActions.addUsers(users);
  const byRegister = new Map<string, Omit<RegisterUser, "id">[]>();
  for (const u of users) byRegister.set(u.registerId, [...(byRegister.get(u.registerId) ?? []), u]);
  const names = new Map([...byName.values()].map((r) => [r.id, r.name]));
  attendanceActions.log(
    [...byRegister].map(([registerId, mapped]) => ({
      action: "Users Mapped",
      register: names.get(registerId) ?? "",
      details: `${mapped.length} ${mapped.length === 1 ? "user" : "users"} mapped from ${file.name} · Roles: ${[
        ...new Set(mapped.flatMap((u) => u.role.split(", ")).filter(Boolean)),
      ].join(", ")}`,
    })),
  );
  return users.length;
}

/** Downloads a single-sheet report (bold header row, then data rows). */
export async function downloadReport(
  fileName: string,
  sheet: string,
  header: string[],
  rows: (string | number | null)[][],
  audit?: AuditInput,
) {
  const { default: writeXlsxFile } = await import("write-excel-file/browser");
  const data: SheetData = [
    header.map((value) => ({ value, fontWeight: "bold" as const })),
    ...rows.map((row) => row.map((v) => (v === "" ? null : v))),
  ];
  const blob = await writeXlsxFile(data, {
    sheet,
    columns: header.map((h) => ({ width: Math.max(14, h.length + 4) })),
    stickyRowsCount: 1,
  }).toBlob();
  saveBlob(blob, fileName);
  if (audit) attendanceActions.log([audit]);
}

/** Saves a copy of a file the user picked (the "Download" button next to an uploaded file). */
export function downloadFile(file: File) {
  saveBlob(file, file.name);
}
