import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Download, Eye, Upload, ChevronLeft, CircleCheck, X, RotateCcw } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";
import { TemplatePreviewDialog } from "@/components/template-preview";
import {
  buildMappingTemplate,
  downloadMappingTemplate,
  downloadFile,
  uploadMappingTemplate,
  type Workbook,
} from "@/lib/templates";

export const Route = createFileRoute("/attendance/upload-mapping")({
  head: () => ({
    meta: [
      { title: "Upload Populated User Mapping Template | City Municipal Corporation" },
      {
        name: "description",
        content: "Upload the filled user mapping template and confirm the upload.",
      },
      {
        property: "og:title",
        content: "Upload Populated User Mapping Template | City Municipal Corporation",
      },
      {
        property: "og:description",
        content: "Upload the filled user mapping template and confirm the upload.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: UploadMappingPage,
});

function UploadMappingPage() {
  const [file, setFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [uploaded, setUploaded] = useState(false);
  const [showSuccess, setShowSuccess] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState<Workbook | null>(null);

  const selectFile = (f: File | null) => {
    setFile(f);
    setError(null);
  };

  const handleConfirm = async () => {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      await uploadMappingTemplate(file);
      setUploaded(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      selectFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      selectFile(e.target.files[0]);
    }
  };

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-28 pt-4">
        <div className="w-full">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: "Upload Populated User Mapping Template" },
            ]}
          />

          <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            {!uploaded && (
              <h1 className="font-condensed text-3xl font-bold text-heading">
                Upload Populated User Mapping Template
              </h1>
            )}
            {!uploaded && (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPreview(buildMappingTemplate())}
                  className="flex items-center gap-2 whitespace-nowrap rounded-md border border-primary bg-white px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary/5">
                  <Eye className="size-4" /> View Generated Template
                </button>
                <button
                  onClick={() => void downloadMappingTemplate()}
                  className="flex items-center gap-2 whitespace-nowrap rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95">
                  <Download className="size-4" /> Download Generated Template
                </button>
              </div>
            )}
          </div>

          {uploaded ? (
            <div className="mt-6 overflow-hidden rounded-lg bg-card shadow-sm">
              <div className="bg-green-700 px-8 py-16 text-center">
                <CircleCheck className="mx-auto size-12 text-white" strokeWidth={1.5} />
                <h2 className="mt-4 font-condensed text-3xl font-bold text-white">
                  Users Mapped Successfully!
                </h2>
              </div>
              <div className="border-t border-border p-6">
                <p className="text-base leading-relaxed text-foreground">
                  The populated user mapping template you uploaded has been added successfully.
                  Download a copy now, and manage it anytime from Manage Registers.
                </p>


                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-muted/30 px-2 py-1.5">
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="flex size-8 items-center justify-center rounded-sm bg-green-700 text-[9px] font-bold text-white">
                      .xlsx
                    </div>
                    <span className="truncate text-sm font-bold text-heading">{file?.name}</span>
                  </div>
                  <button
                    onClick={() => file && downloadFile(file)}
                    className="flex items-center gap-1.5 whitespace-nowrap rounded-md border border-primary bg-white px-3 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/5">
                    <Download className="size-3.5" /> Download
                  </button>
                </div>
              </div>
            </div>
          ) : file ? (
            <div className="relative mt-6 rounded-lg bg-card p-4 shadow-sm">
              <button
                onClick={() => selectFile(null)}
                aria-label="Remove file"
                className="absolute right-3 top-3 text-heading transition-colors hover:text-destructive"
              >
                <X className="size-4" />
              </button>
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-muted/30 px-4 py-3">
                <div className="flex min-w-0 items-center gap-3">
                  <div className="flex size-8 items-center justify-center rounded-sm bg-green-700 text-[9px] font-bold text-white">
                    .xlsx
                  </div>
                  <span className="truncate text-sm font-bold text-heading">{file.name}</span>
                </div>
                <div className="flex items-center gap-3">
                  <label className="flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-md border border-primary bg-white px-3 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/5">
                    <Upload className="size-3.5" /> Re-Upload
                    <input
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      className="hidden"
                      onChange={handleFileChange}
                    />
                  </label>
                  <button
                    onClick={() => file && downloadFile(file)}
                    className="flex items-center gap-1.5 whitespace-nowrap rounded-md border border-primary bg-white px-3 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/5">
                    <Download className="size-3.5" /> Download
                  </button>
                </div>
              </div>
              {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
            </div>
          ) : (
            <div
              className={`mt-6 flex flex-col items-center justify-center rounded-lg border-2 border-dashed bg-card px-6 py-14 text-center transition-colors ${
                dragActive ? "border-primary bg-primary/[0.03]" : "border-border"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <div className="flex size-12 items-center justify-center rounded-full bg-muted">
                <Upload className="size-6 text-muted-foreground" />
              </div>
              <p className="mt-4 text-sm text-muted-foreground">
                Drag and drop your filled excel sheet or{" "}
                <label className="cursor-pointer font-medium text-primary hover:underline">
                  browse in my files
                  <input
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </label>
              </p>
            </div>
          )}
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 border-t border-border bg-card px-6 py-4">
        <div className="flex w-full items-center justify-between">
          {uploaded ? (
            <>
              <button
                onClick={() => {
                  setUploaded(false);
                  setFile(null);
                }}
                className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
              >
                <RotateCcw className="size-4" /> Map More Users
              </button>
              <Link
                to="/attendance/registers"
                className="flex items-center gap-2 rounded-md bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95"
              >
                Go to Manage Registers
              </Link>

            </>
          ) : (
            <>
              <Link
                to="/attendance/map-template"
                className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
              >
                <ChevronLeft className="size-4" /> Back
              </Link>
              <button
                disabled={!file || busy}
                onClick={() => void handleConfirm()}
                className="flex items-center gap-2 rounded-md bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Upload className="size-4" /> Confirm Upload
              </button>
            </>
          )}
        </div>
      </footer>

      {showSuccess && !uploaded && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-6"
          onClick={() => setShowSuccess(false)}
        >
          <div
            className="w-full max-w-xl overflow-hidden rounded-xl bg-card shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-success px-8 py-10 text-center">
              <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-success-foreground/20">
                <CircleCheck className="size-7 text-success-foreground" strokeWidth={1.5} />
              </div>
              <h2 className="mt-4 font-condensed text-2xl font-bold text-success-foreground">
                User Mapping Template Generated
              </h2>
            </div>
            <div className="p-6">
              <p className="text-sm leading-relaxed text-muted-foreground">
                Your user mapping template has been generated. Download the template, fill in the user
                details, and upload it back here.
              </p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <button
                  onClick={() => {
                    setShowSuccess(false);
                    setPreview(buildMappingTemplate());
                  }}
                  className="flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-md border border-primary bg-white px-4 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
                >
                  <Eye className="size-4" /> View Generated Template
                </button>
                <button
                  onClick={() => {
                    setShowSuccess(false);
                    void downloadMappingTemplate();
                  }}
                  className="flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95"
                >
                  <Download className="size-4" /> Download Generated Template
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      <TemplatePreviewDialog
        workbook={preview}
        title="User Mapping Template"
        onClose={() => setPreview(null)}
      />
    </AppShell>
  );
}
