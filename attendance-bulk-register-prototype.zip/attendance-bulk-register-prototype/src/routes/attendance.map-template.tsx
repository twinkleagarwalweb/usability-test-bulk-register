import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Check, ChevronLeft, Info } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";

export const Route = createFileRoute("/attendance/map-template")({
  head: () => ({
    meta: [
      { title: "Customize User Mapping Template | City Municipal Corporation" },
      {
        name: "description",
        content:
          "Set up your user mapping template by defining enrollment dates, de-enrollment dates, and team codes.",
      },
      {
        property: "og:title",
        content: "Customize User Mapping Template | City Municipal Corporation",
      },
      {
        property: "og:description",
        content:
          "Set up your user mapping template by defining enrollment dates, de-enrollment dates, and team codes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MapTemplatePage,
});

const STEPS = ["Enrollment date", "De-enrolment date", "Team mapping"];

const ENROLL_OPTIONS = [
  { label: "Set per user", text: "Set the enrollment date for each user in the generated template." },
  { label: "Same date for all users", text: "Use one date for everyone in the template." },
];

const DEENROLL_OPTIONS = [
  { label: "Skip the de-enrolment date.", text: "Don’t set a de-enrolment date." },
  { label: "Set per user", text: "Set the de-enrollment date for each user in the generated template." },
  { label: "Same date for all users", text: "Use one date for everyone in the template." },
];

function OptionCard({
  label,
  text,
  selected,
  onSelect,
}: {
  label: string;
  text: string;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`flex w-full items-start gap-3 rounded-lg border p-4 text-left transition-colors ${
        selected
          ? "border-primary bg-selected-bg"
          : "border-border bg-info-bg hover:border-muted-foreground/30"
      }`}
    >
      <span
        className={`flex size-4.5 shrink-0 items-center justify-center rounded-full border-2 ${
          selected ? "border-primary" : "border-muted-foreground/40"
        }`}
      >
        {selected && <span className="size-2 rounded-full bg-primary" />}
      </span>
      <span>
        <span className="block text-sm font-bold text-heading">{label}</span>
        <span className="mt-1 block text-xs text-muted-foreground">{text}</span>
      </span>
    </button>
  );
}

function MapTemplatePage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [enrollMode, setEnrollMode] = useState<string | null>("Same date for all users");
  const [enrollDate, setEnrollDate] = useState("2026-02-12");
  const [deenrollMode, setDeenrollMode] = useState<string | null>("Skip the de-enrolment date.");
  const [deenrollDate, setDeenrollDate] = useState("2026-02-28");

  const canContinue =
    step === 0 ? !!enrollMode : step === 1 ? !!deenrollMode : true;

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-28 pt-4">
        <div className="w-full">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: "Customize your User Mapping Template" },
            ]}
          />
          <h1 className="mt-3 font-condensed text-3xl font-bold text-heading">
            Customize your User Mapping Template
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Set up your user mapping template by defining enrollment dates, de-enrollment dates, and
            team codes.
          </p>

          {/* Stepper */}
          <div className="relative mt-8 flex justify-between">
            {STEPS.map((label, i) => (
              <div
                key={label}
                className="relative z-10 flex flex-1 flex-col items-center first:items-start last:items-end"
              >
                <div className="flex w-full items-center">
                  {i > 0 && <div className={`h-0.5 flex-1 ${i <= step ? "bg-primary" : "bg-border"}`} />}
                  <div
                    className={`flex size-7 items-center justify-center rounded-full text-xs font-semibold ${
                      i <= step
                        ? "bg-primary text-primary-foreground"
                        : "border border-border bg-card text-muted-foreground"
                    }`}
                  >
                    {i < step ? <Check className="size-4" strokeWidth={3} /> : i + 1}
                  </div>
                  {i < STEPS.length - 1 && (
                    <div className={`h-0.5 flex-1 ${i < step ? "bg-primary" : "bg-border"}`} />
                  )}
                </div>
                <span
                  className={`mt-2 text-xs ${
                    i === step ? "font-bold text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {label}
                </span>
              </div>
            ))}
          </div>

          <div className="mt-5 rounded-lg border border-border bg-card px-8 py-6">
            {step === 0 && (
              <>
                <h2 className="text-2xl font-bold text-heading">
                  How should the enrollment date be set?
                </h2>
                <div className="mt-4 space-y-3">
                  {ENROLL_OPTIONS.map((o) => (
                    <OptionCard
                      key={o.label}
                      label={o.label}
                      text={o.text}
                      selected={enrollMode === o.label}
                      onSelect={() => setEnrollMode(o.label)}
                    />
                  ))}
                </div>

                {enrollMode === "Same date for all users" && (
                  <div className="mt-6 border-t border-border pt-6">
                    <div className="grid grid-cols-1 items-start gap-x-6 gap-y-2 md:grid-cols-[minmax(180px,2fr)_3fr]">
                      <label className="text-sm font-bold text-foreground">
                        Enrollment Date <span className="text-primary">*</span>
                      </label>
                      <div>
                        <input
                          type="date"
                          value={enrollDate}
                          onChange={(e) => setEnrollDate(e.target.value)}
                          className="w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                        />
                        <p className="mt-1 text-xs text-muted-foreground">The campaign start date is selected by default. You can change it if needed.</p>
                      </div>
                    </div>
                  </div>
                )}

              </>
            )}

            {step === 1 && (
              <>
                <h2 className="text-2xl font-bold text-heading">
                  How should the de-enrolment date be set?
                </h2>
                <div className="mt-4 space-y-3">
                  {DEENROLL_OPTIONS.map((o) => (
                    <OptionCard
                      key={o.label}
                      label={o.label}
                      text={o.text}
                      selected={deenrollMode === o.label}
                      onSelect={() => setDeenrollMode(o.label)}
                    />
                  ))}
                </div>

                {deenrollMode === "Same date for all users" && (
                  <div className="mt-6 border-t border-border pt-6">
                    <div className="grid grid-cols-1 items-start gap-x-6 gap-y-2 md:grid-cols-[minmax(180px,2fr)_3fr]">
                      <label className="text-sm font-bold text-foreground">
                        De-enrolment Date <span className="text-primary">*</span>
                      </label>
                      <div>
                        <input
                          type="date"
                          value={deenrollDate}
                          onChange={(e) => setDeenrollDate(e.target.value)}
                          className="w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                        />
                        <p className="mt-1 text-xs text-muted-foreground">The campaign end date is selected by default. You can change it if needed.</p>
                      </div>
                    </div>
                  </div>
                )}

              </>
            )}

            {step === 2 && (
              <>
                <h2 className="text-2xl font-bold text-heading">Team mapping</h2>
                {/* Display only: team codes are always set per user, so there is nothing to choose. */}
                <div className="mt-4 flex items-start gap-3 rounded-lg border border-border bg-info-bg p-4">
                  <Info className="mt-0.5 size-4.5 shrink-0 text-heading" />
                  <div>
                    <p className="text-sm font-bold text-heading">Team is mapped per user</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Each user's team code is filled in the Team Code column of the Frontline Workers
                      sheet in the generated template. Users with the same code belong to the same
                      team. Attendance markers and approvers don't need a team code.
                    </p>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 border-t border-border bg-card px-6 py-4">
        <div className="flex w-full items-center justify-between">
          {step > 0 ? (
            <button
              onClick={() => setStep((s) => s - 1)}
              className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
            >
              <ChevronLeft className="size-4" /> Back
            </button>
          ) : (
            <Link
              to="/attendance/map-users"
              className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
            >
              <ChevronLeft className="size-4" /> Back
            </Link>
          )}
          <button
            disabled={!canContinue}
            onClick={() =>
              step === 2 ? navigate({ to: "/attendance/upload-mapping" }) : setStep((s) => s + 1)
            }
            className="rounded-md bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {step === 2 ? "Generate Template" : "Next"}
          </button>
        </div>
      </footer>
    </AppShell>
  );
}
