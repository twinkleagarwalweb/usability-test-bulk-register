import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronDown, ChevronLeft, Search } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";
import { selectRegisters, useAttendanceStore, type AuditEntry } from "@/lib/attendance-store";

export const Route = createFileRoute("/attendance/audit-log")({
  head: () => ({
    meta: [
      { title: "Attendance Audit Log | City Municipal Corporation" },
      {
        name: "description",
        content:
          "Track who created or edited attendance registers and who mapped users, with dates and details.",
      },
      { property: "og:title", content: "Attendance Audit Log | City Municipal Corporation" },
      {
        property: "og:description",
        content:
          "Track who created or edited attendance registers and who mapped users, with dates and details.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuditLogPage,
});

// Actions the attendance setup flow records (see attendanceActions.log).
const ACTIONS = [
  "Template Downloaded",
  "Register Generated",
  "Register Edited",
  "Register Deleted",
  "Users Mapped",
  "Register Downloaded",
];

// History for the seed registers, consistent with their boundaries, frequency,
// officers and mapped users. Actions taken in the prototype are added on top.
const SEED_ENTRIES: AuditEntry[] = [
  {
    id: "a-10",
    action: "Register Downloaded",
    register: "BILL 16273676",
    details: "Signature list downloaded · 12 users",
    user: "Meera Iyer",
    role: "Attendance Officer",
    at: "2025-08-25T17:05:00+05:30",
  },
  {
    id: "a-9",
    action: "Register Downloaded",
    register: "BILL 16273677",
    details: "Attendance report downloaded · 43 users",
    user: "Rahul Verma",
    role: "Attendance Officer",
    at: "2025-08-22T18:20:00+05:30",
  },
  {
    id: "a-8",
    action: "Users Mapped",
    register: "BILL 16273677",
    details: "43 users mapped from Attendee_Template.xlsx · Roles: DISTRIBUTOR, FIELD_SUPPORT, TEAM_SUPERVISOR",
    user: "Suresh Patel",
    role: "Data Entry Operator",
    at: "2025-08-19T15:41:00+05:30",
  },
  {
    id: "a-7",
    action: "Users Mapped",
    register: "BILL 16273676",
    details: "12 users mapped from Attendee_Template.xlsx · Roles: DISTRIBUTOR, WAREHOUSE_MANAGER",
    user: "Suresh Patel",
    role: "Data Entry Operator",
    at: "2025-08-19T15:40:00+05:30",
  },
  {
    id: "a-6",
    action: "Template Downloaded",
    register: "",
    details: "User mapping template downloaded for BILL 16273676, BILL 16273677",
    user: "Suresh Patel",
    role: "Data Entry Operator",
    at: "2025-08-19T10:05:00+05:30",
  },
  ...[
    { id: "a-5", register: "BILL 16273677", boundary: "State, LGA, Ward, Settlement", frequency: "once", officer: "Rahul Verma", minute: "36" },
    { id: "a-4", register: "BILL 16273676", boundary: "State, LGA, Ward", frequency: "twice", officer: "Meera Iyer", minute: "35" },
    { id: "a-3", register: "BILL 16273675", boundary: "State, LGA", frequency: "once", officer: "Anita Sharma", minute: "34" },
    { id: "a-2", register: "BILL 16273674", boundary: "State, LGA, Ward", frequency: "twice", officer: "Rahul Verma", minute: "33" },
    { id: "a-1", register: "BILL 16273673", boundary: "State, LGA, Ward, Settlement", frequency: "once", officer: "Anita Sharma", minute: "32" },
  ].map((r) => ({
    id: r.id,
    action: "Register Generated",
    register: r.register,
    details: `Created from Attendance_Register_Template.xlsx · Boundary level: ${r.boundary} · Attendance ${r.frequency} a day · Officer: ${r.officer}`,
    user: "Aisha Bello",
    role: "Campaign Supervisor",
    at: `2025-08-18T11:${r.minute}:00+05:30`,
  })),
  {
    id: "a-0",
    action: "Template Downloaded",
    register: "",
    details: "Attendance register template downloaded · 5 registers · 1 session a day",
    user: "Aisha Bello",
    role: "Campaign Supervisor",
    at: "2025-08-18T09:10:00+05:30",
  },
];

const formatTimestamp = (iso: string) =>
  new Date(iso)
    .toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    })
    .replace(/ (\d{4}),?/, " $1,");

function AuditLogPage() {
  const [action, setAction] = useState("");
  const [role, setRole] = useState("");
  const [register, setRegister] = useState("");
  const store = useAttendanceStore();
  const registerIds = useMemo(
    () => new Map(selectRegisters(store).map((r) => [r.name, r.id])),
    [store],
  );

  // Recorded actions first (newest on top), then the seed history.
  const entries = useMemo(() => [...store.auditLog, ...SEED_ENTRIES], [store.auditLog]);

  const filtered = useMemo(
    () =>
      entries.filter(
        (e) =>
          (!register || e.register === register) &&
          (!action || e.action === action) &&
          (!role || e.role === role),
      ),
    [entries, register, action, role],
  );

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-28 pt-4">
        <div className="w-full">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: "Audit Log" },
            ]}
          />

          <div className="mt-4 rounded-lg border border-border bg-card px-6 py-5">
            <h1 className="font-condensed text-3xl font-bold text-heading">Audit Log</h1>

            <div className="mt-5 flex flex-wrap items-end gap-4">
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">Register Name</label>
                <div className="relative mt-1">
                  <select
                    value={register}
                    onChange={(e) => setRegister(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {Array.from(new Set(entries.map((e) => e.register).filter(Boolean))).sort().map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">Action</label>
                <div className="relative mt-1">
                  <select
                    value={action}
                    onChange={(e) => setAction(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {ACTIONS.map((a) => (
                      <option key={a} value={a}>
                        {a}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">Role</label>
                <div className="relative mt-1">
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {Array.from(new Set(entries.map((e) => e.role))).map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="ml-auto flex items-center gap-4">
                <button
                  onClick={() => {
                    setAction("");
                    setRole("");
                    setRegister("");
                  }}
                  className="text-sm font-medium text-primary hover:underline"
                >
                  Clear Search
                </button>
                <button className="flex items-center gap-2 rounded-md bg-primary px-5 py-2 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95">
                  <Search className="size-4" /> Search
                </button>
              </div>
            </div>
          </div>

          <div className="mt-4 overflow-hidden rounded-lg border border-border bg-card p-4">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[750px] border-collapse text-left">
                <thead>
                  <tr className="bg-muted">
                    {["Register Name", "Action", "Details", "Role", "Date & Time"].map(
                      (h, i, arr) => (
                        <th
                          key={h}
                          className={`px-4 py-3 text-xs font-bold text-heading ${
                            i === 0 ? "rounded-l-md" : ""
                          } ${i === arr.length - 1 ? "rounded-r-md" : ""}`}
                        >
                          {h}
                        </th>
                      ),
                    )}
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center text-sm text-muted-foreground">
                        No audit log entries match the selected filters.
                      </td>
                    </tr>
                  )}
                  {filtered.map((e) => (
                    <tr
                      key={e.id}
                      className="border-b border-border transition-colors last:border-0 hover:bg-muted/40"
                    >
                      <td className="px-4 py-3 text-sm font-medium">
                        {registerIds.has(e.register) ? (
                          <Link
                            className="text-primary underline"
                            to="/attendance/registers/$registerId"
                            params={{ registerId: registerIds.get(e.register)! }}
                            search={{ from: "audit-log" }}
                          >
                            {e.register}
                          </Link>
                        ) : (
                          // Campaign-level actions have no register; deleted registers can't be opened.
                          <span className={e.register ? "text-foreground" : "text-muted-foreground"}>
                            {e.register || "—"}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <span className="rounded-xs bg-chip px-2 py-1 text-[11px] font-semibold text-heading">
                          {e.action}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-foreground">{e.details}</td>
                      <td className="px-4 py-3 text-sm text-foreground">{e.role}</td>
                      <td className="whitespace-nowrap px-4 py-3 text-sm text-muted-foreground">
                        {formatTimestamp(e.at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 border-t border-border bg-card px-6 py-4">
        <div className="flex w-full items-center">
          <Link
            to="/attendance"
            className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
          >
            <ChevronLeft className="size-4" /> Back
          </Link>
        </div>
      </footer>
    </AppShell>
  );
}
