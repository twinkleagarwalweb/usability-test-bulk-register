import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { X, ClipboardList, Users, FolderOpen } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";
import registerArt from "@/assets/attendance-illustration.png";

const REGISTER_COUNT = 5;

export const Route = createFileRoute("/attendance/")({
  head: () => ({
    meta: [
      { title: "Attendance Setup & Management | City Municipal Corporation" },
      {
        name: "description",
        content:
          "Create, manage, and assign users to attendance registers for your campaign.",
      },
      {
        property: "og:title",
        content: "Attendance Setup & Management | City Municipal Corporation",
      },
      {
        property: "og:description",
        content:
          "Create, manage, and assign users to attendance registers for your campaign.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AttendancePage,
});

function AttendancePage() {
  const [showIntro, setShowIntro] = useState(true);
  const [registerGenerated, setRegisterGenerated] = useState(false);

  useEffect(() => {
    try {
      setRegisterGenerated(localStorage.getItem("attendanceRegisterGenerated") === "true");
    } catch {
      setRegisterGenerated(false);
    }
  }, []);

  return (
    <AppShell>
      <main className="min-w-0 flex-1 px-6 pb-12 pt-4">
        {registerGenerated ? (
          <div className="max-w-5xl">
            <Breadcrumb
              items={[
                { label: "Home", to: "/" },
                { label: "Attendance Setup & Management" },
              ]}
            />

            <h1 className="mt-3 font-condensed text-3xl font-bold text-heading">
              Attendance Setup &amp; Management
            </h1>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Create, manage, and assign users to attendance registers.
            </p>

            <div className="mt-8 grid grid-cols-1 gap-4 lg:grid-cols-3">
              <Link
                to="/attendance/customize"
                className="rounded-md border border-border bg-card p-5 text-left transition-shadow hover:shadow-md"
              >
                <div className="flex size-9 items-center justify-center rounded-md bg-primary/10">
                  <ClipboardList className="size-4.5 text-primary" />
                </div>
                <h2 className="mt-4 text-lg font-bold text-heading">
                  Generate New Register
                </h2>
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                  Create attendance registers using boundary-based templates and upload them to the
                  system.
                </p>
              </Link>

              {registerGenerated ? (
                <Link
                  to="/attendance/map-users"
                  className="rounded-md border border-border bg-card p-5 text-left transition-shadow hover:shadow-md"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex size-9 items-center justify-center rounded-md bg-primary/10">
                      <Users className="size-4.5 text-primary" />
                    </div>
                    <span className="rounded-xs bg-red-100 px-2 py-0.5 text-[11px] font-semibold text-red-700 tabular-nums">
                      50 users yet to be mapped
                    </span>
                  </div>
                  <h2 className="mt-4 text-lg font-bold text-heading">
                    Map Users to Registers
                  </h2>
                  <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                    Assign campaign users to attendance registers to enable attendance tracking.
                  </p>
                </Link>
              ) : (
                <div
                  aria-disabled="true"
                  className="rounded-md border border-border bg-card p-5 text-left opacity-60"
                >
                  <div className="flex size-9 items-center justify-center rounded-md bg-muted">
                    <Users className="size-4.5 text-muted-foreground" />
                  </div>
                  <h2 className="mt-4 text-lg font-bold text-heading">
                    Map Users to Registers
                  </h2>
                  <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                    Assign campaign users to attendance registers to enable attendance tracking.
                  </p>
                </div>
              )}

              <Link
                to="/attendance/registers"
                className="rounded-md border border-border bg-card p-5 text-left transition-shadow hover:shadow-md"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex size-9 items-center justify-center rounded-md bg-primary/10">
                    <FolderOpen className="size-4.5 text-primary" />
                  </div>
                  <span className="rounded-xs bg-chip px-2 py-0.5 text-[11px] font-semibold text-heading tabular-nums">
                    {REGISTER_COUNT} registers
                  </span>
                </div>
                <h2 className="mt-4 text-lg font-bold text-heading">
                  Manage Registers
                </h2>
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                  View and manage attendance registers that have already been created.
                </p>
              </Link>
            </div>
          </div>
        ) : (
          <>
            <div className="max-w-5xl">
              <Breadcrumb
                items={[
                  { label: "Home", to: "/" },
                  { label: "Attendance Setup & Management" },
                ]}
              />
            </div>
            <div className="mt-8 flex w-full justify-center">
              <div className="flex w-full max-w-none flex-col items-center rounded-md border border-border bg-card p-6 text-center">
                <img
                  src={registerArt}
                  alt="Illustration of an attendance register clipboard"
                  className="h-44 w-auto object-contain"
                  loading="lazy"
                  width={1024}
                  height={1024}
                />

                <h2 className="mt-4 text-2xl font-bold text-heading">
                  Start by creating your attendance register
                </h2>

                <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                  Create an attendance register to record and manage attendance for campaign users.
                </p>
                <Link
                  to="/attendance/customize"
                  className="mt-4 inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95"
                >
                  Generate New Register
                </Link>
              </div>
            </div>
          </>
        )}
      </main>

      {!registerGenerated && showIntro && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="What is an attendance register?"
        >
          <div className="relative w-full max-w-md rounded-md bg-card p-6 pt-8 shadow-xl">
            <button
              aria-label="Close"
              onClick={() => setShowIntro(false)}
              className="absolute right-3 top-3 flex size-8 items-center justify-center rounded-full bg-muted text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
            >
              <X className="size-5" />
            </button>

            <img
              src={registerArt}
              alt="Illustration of an attendance register clipboard"
              className="mx-auto h-32 w-32 object-contain"
              width={1024}
              height={1024}
            />

            <h2 className="mt-4 text-center text-xl font-bold text-heading">
              What is an attendance register?
            </h2>
            <p className="mt-3 rounded-lg bg-info-bg px-4 py-3 text-center text-xs leading-relaxed text-muted-foreground">
              An attendance register is a ready-to-use list for recording who attended a campaign
              event.
            </p>

            <hr className="mt-5 border-border" />
            <h3 className="mt-4 text-sm font-bold text-heading">What's inside?</h3>
            <p className="mt-0.5 text-xs text-muted-foreground">Each register contains:</p>
            <div className="mt-2 grid grid-cols-3 gap-2">
              {[
                { label: "Where", text: "The boundary the register is for" },
                { label: "What", text: "The event attendance is being recorded for" },
                { label: "When", text: "The session when attendance is recorded" },
              ].map((col) => (
                <div key={col.label} className="rounded-lg bg-info-bg p-2.5">
                  <span className="rounded-md bg-chip px-1.5 py-0.5 text-[11px] font-semibold text-heading">
                    {col.label}
                  </span>
                  <p className="mt-1.5 text-[11px] leading-snug text-muted-foreground">
                    {col.text}
                  </p>
                </div>
              ))}
            </div>

            <hr className="mt-5 border-border" />
            <h3 className="mt-4 text-sm font-bold text-heading">What can you do with it?</h3>
            <p className="mt-2 rounded-lg bg-info-bg px-4 py-3 text-xs leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">Add or remove users</span> from the
              register, then mark each user as{" "}
              <span className="rounded-md bg-green-100 px-1.5 py-0.5 text-[11px] font-medium text-green-800">
                Present
              </span>{" "}
              or{" "}
              <span className="rounded-md bg-red-100 px-1.5 py-0.5 text-[11px] font-medium text-red-800">
                Absent
              </span>{" "}
              as attendance is recorded.
            </p>

            <Link
              to="/attendance/customize"
              className="mt-5 block w-full rounded-md bg-primary px-4 py-2.5 text-center text-sm font-medium text-primary-foreground transition-colors hover:brightness-95"
            >
              Generate New Register
            </Link>
          </div>
        </div>
      )}
    </AppShell>
  );
}
