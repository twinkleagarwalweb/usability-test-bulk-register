import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";

export const Route = createFileRoute("/attendance/new-register")({
  head: () => ({
    meta: [
      { title: "Generate New Register | City Municipal Corporation" },
      {
        name: "description",
        content:
          "Choose how to generate a new attendance register: start from scratch or reuse an existing register template.",
      },
      {
        property: "og:title",
        content: "Generate New Register | City Municipal Corporation",
      },
      {
        property: "og:description",
        content:
          "Choose how to generate a new attendance register: start from scratch or reuse an existing register template.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NewRegisterPage,
});

type Template = {
  id: string;
  name: string;
  boundary: string;
  frequency: string;
  registers: string[];
};

const TEMPLATES: Template[] = [
  {
    id: "t-1",
    name: "Template 1",
    boundary: "State, LGA, Ward, Settlement",
    frequency: "Once",
    registers: ["BILL 16273673", "BILL 16273674"],
  },
  {
    id: "t-2",
    name: "Template 2",
    boundary: "State, LGA, Ward",
    frequency: "Twice",
    registers: ["BILL 16273675"],
  },
  {
    id: "t-3",
    name: "Template 3",
    boundary: "State, LGA",
    frequency: "Once",
    registers: ["BILL 16273676", "BILL 16273677"],
  },
];

function ModeCard({
  label,
  text,
  selected,
  onSelect,
}: {
  label: string;
  text: string;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`flex w-full items-start gap-3 rounded-lg border p-4 text-left transition-colors ${
        selected
          ? "border-primary bg-selected-bg"
          : "border-border bg-info-bg hover:border-muted-foreground/30"
      }`}
    >
      <span
        className={`mt-0.5 flex size-4.5 shrink-0 items-center justify-center rounded-full border-2 ${
          selected ? "border-primary" : "border-muted-foreground/40"
        }`}
      >
        {selected && <span className="size-2 rounded-full bg-primary" />}
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-bold text-heading">{label}</span>
        <span className="mt-1 block text-xs text-muted-foreground">{text}</span>
      </span>
    </button>
  );
}

function NewRegisterPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"scratch" | "existing" | null>(null);
  const [templateId, setTemplateId] = useState<string | null>(null);

  const selectedTemplate = TEMPLATES.find((t) => t.id === templateId) ?? null;
  const canContinue = mode === "scratch" || (mode === "existing" && !!templateId);

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-28 pt-4">
        <div className="w-full">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: "Generate New Register" },
            ]}
          />
          <h1 className="mt-3 font-condensed text-3xl font-bold text-heading">
            Generate New Register
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Choose how you want to generate a new attendance register.
          </p>

          <div className="mt-5 rounded-lg border border-border bg-card px-8 py-6">
            <h2 className="text-2xl font-bold text-heading">
              How do you want to generate a new register?
            </h2>
            <div className="mt-4 space-y-3">
              <ModeCard
                label="Start from scratch"
                text="Customize a new template by choosing the boundary level and attendance frequency, then generate and upload the register."
                selected={mode === "scratch"}
                onSelect={() => setMode("scratch")}
              />
              <ModeCard
                label="Use an existing register template"
                text="Reuse a template that is already configured. You'll see its structure and the registers mapped to it before continuing."
                selected={mode === "existing"}
                onSelect={() => setMode("existing")}
              />
            </div>

            {mode === "existing" && (
              <div className="mt-6 rounded-lg border border-border bg-info-bg p-6">
                <h3 className="text-base font-bold text-heading">
                  Which existing template you want to use?{" "}
                  <span className="text-primary">*</span>
                </h3>
                <div className="mt-4 space-y-3">
                  {TEMPLATES.map((t) => {
                    const active = templateId === t.id;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setTemplateId(t.id)}
                        className={`w-full rounded-lg border p-4 text-left transition-colors ${
                          active
                            ? "border-primary bg-selected-bg"
                            : "border-border bg-card hover:border-muted-foreground/30"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <span
                            className={`mt-0.5 flex size-4.5 shrink-0 items-center justify-center rounded-full border-2 ${
                              active ? "border-primary" : "border-muted-foreground/40"
                            }`}
                          >
                            {active && <span className="size-2 rounded-full bg-primary" />}
                          </span>
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-sm font-bold text-accent">{t.name}</span>
                              <span className="rounded-full bg-info px-2 py-0.5 text-xs font-medium text-info-foreground">
                                {t.registers.length}{" "}
                                {t.registers.length === 1 ? "register" : "registers"} with this
                                template
                              </span>
                            </div>

                            <div className="mt-3 grid sm:grid-cols-2">
                              {[
                                { label: "Boundary Level", value: t.boundary },
                                { label: "Attendance Frequency", value: t.frequency },
                              ].map((f, i, arr) => (
                                <div
                                  key={f.label}
                                  className={`px-4 first:pl-0 last:pr-0 ${
                                    i < arr.length - 1 ? "border-r border-border" : ""
                                  }`}
                                >
                                  <span className="block text-[11px] font-semibold uppercase tracking-wide text-black/60">
                                    {f.label}
                                  </span>
                                  <span className="mt-0.5 block text-sm font-medium text-black">
                                    {f.value}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 border-t border-border bg-card px-6 py-4">
        <div className="flex w-full items-center justify-between">
          <Link
            to="/attendance"
            className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
          >
            <ChevronLeft className="size-4" /> Back
          </Link>
          <button
            disabled={!canContinue}
            onClick={() =>
              mode === "scratch"
                ? navigate({ to: "/attendance/customize" })
                : navigate({ to: "/attendance/upload", search: { fromExisting: "true" } })
            }
            className="rounded-md bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {mode === "existing" && selectedTemplate ? "Use this Template" : "Continue"}
          </button>
        </div>
      </footer>
    </AppShell>
  );
}
