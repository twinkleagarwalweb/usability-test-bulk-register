import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown, ChevronUp, GripVertical } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";
import { attendanceActions } from "@/lib/attendance-store";

export const Route = createFileRoute("/attendance/customize")({
  head: () => ({
    meta: [
      { title: "Customize Attendance Register Template | City Municipal Corporation" },
      {
        name: "description",
        content:
          "Customize your attendance register template by selecting the boundaries and attendance frequency.",
      },
      {
        property: "og:title",
        content: "Customize Attendance Register Template | City Municipal Corporation",
      },
      {
        property: "og:description",
        content:
          "Customize your attendance register template by selecting the boundaries and attendance frequency.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CustomizePage,
});

const BOUNDARIES = [
  { label: "State", count: "1 state" },
  { label: "LGA", count: "6 LGAs" },
  { label: "Ward", count: "14 wards" },
  { label: "Settlement", count: "96 settlements" },
];

const FREQUENCIES = [
  { label: "Once a day", chip: "One register with a single session" },
  { label: "Twice a day", chip: "One register split into Session 1 and Session 2" },
];

function Checkbox({ checked }: { checked: boolean }) {
  return (
    <span
      className={`flex size-4.5 shrink-0 items-center justify-center rounded-xs border ${
        checked ? "border-primary bg-primary text-primary-foreground" : "border-input bg-card"
      }`}
    >
      {checked && <Check className="size-3" strokeWidth={3} />}
    </span>
  );
}

function Radio({ checked }: { checked: boolean }) {
  return (
    <span
      className={`flex size-4.5 shrink-0 items-center justify-center rounded-full border-2 ${
        checked ? "border-primary" : "border-input"
      }`}
    >
      {checked && <span className="size-2 rounded-full bg-primary" />}
    </span>
  );
}

function CustomizePage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [freq, setFreq] = useState<string | null>(null);

  // Close the boundary dropdown on outside click or Escape.
  useEffect(() => {
    if (!open) return;
    const onPointerDown = (e: PointerEvent) => {
      if (!dropdownRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  const allSelected = selected.length === BOUNDARIES.length;
  const toggle = (label: string) =>
    setSelected((s) => (s.includes(label) ? s.filter((x) => x !== label) : [...s, label]));

  const canContinue = step === 0 ? selected.length > 0 : !!freq;

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-28 pt-4">
        <div className="w-full">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: "Customize your Attendance Register Template" },
            ]}
          />
          <h1 className="mt-3 font-condensed text-3xl font-bold text-heading">
            Customize your Attendance Register Template
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Customize your attendance register template by selecting the boundaries and attendance frequency.
          </p>

          <div className="mt-5 rounded-lg border border-border bg-card px-8 py-6">
            {step === 0 && (
              <>
                <h2 className="text-2xl font-bold text-heading">
                  What boundaries are you generating registers for?
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Select one or more boundary levels from the dropdown below. We'll create a
                  register for every boundary you select.
                </p>

                <div className="mt-5 grid gap-2 sm:grid-cols-[216px_minmax(0,1fr)] sm:items-center sm:gap-6">
                  <label className="text-sm font-bold text-foreground">
                    Boundary level <span className="text-primary">*</span>
                  </label>
                  <div ref={dropdownRef} className="relative flex-1">
                    <button
                      type="button"
                      onClick={() => setOpen((o) => !o)}
                      aria-expanded={open}
                      className={`flex w-full items-center justify-between rounded-md border bg-card px-3 py-2.5 text-left text-sm ${
                        open ? "border-primary" : "border-input"
                      }`}
                    >
                      <span className={selected.length ? "text-foreground" : "text-muted-foreground"}>
                        {selected.length ? selected.join(", ") : "Select boundaries..."}
                      </span>
                      {open ? (
                        <ChevronUp className="size-4 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="size-4 text-muted-foreground" />
                      )}
                    </button>

                    {open && (
                      <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-md border border-border bg-card shadow-lg">
                        <button
                          type="button"
                          onClick={() =>
                            setSelected(allSelected ? [] : BOUNDARIES.map((b) => b.label))
                          }
                          className="flex w-full items-center gap-3 border-b border-border px-3 py-2.5 text-left hover:bg-muted"
                        >
                          <Checkbox checked={allSelected} />
                          <span className="text-sm font-semibold text-primary">Select All</span>
                        </button>
                        {BOUNDARIES.map((b) => (
                          <button
                            key={b.label}
                            type="button"
                            onClick={() => toggle(b.label)}
                            className="flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-muted"
                          >
                            <Checkbox checked={selected.includes(b.label)} />
                            <GripVertical className="size-4 text-muted-foreground" />
                            <span className="text-sm font-semibold text-foreground">{b.label}</span>
                            <span className="ml-auto text-xs text-muted-foreground">{b.count}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </>
            )}

            {step === 1 && (
              <>
                <h2 className="text-2xl font-bold text-heading">
                  How many times will attendance be recorded each day?
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Choose how many times attendance will be recorded each day.
                </p>
                <div className="mt-4 space-y-3">
                  {FREQUENCIES.map((f) => (
                    <button
                      key={f.label}
                      type="button"
                      onClick={() => setFreq(f.label)}
                      className={`flex w-full items-start gap-3 rounded-md border p-4 text-left transition-colors ${
                        freq === f.label
                          ? "border-primary bg-selected-bg"
                          : "border-border bg-info-bg hover:border-muted-foreground/30"
                      }`}
                    >
                      <span
                        className={`flex size-4.5 shrink-0 items-center justify-center rounded-full border-2 ${
                          freq === f.label ? "border-primary" : "border-muted-foreground/40"
                        }`}
                      >
                        {freq === f.label && <span className="size-2 rounded-full bg-primary" />}
                      </span>
                      <span>
                        <span className="block text-sm font-bold text-heading">{f.label}</span>
                        <span className="mt-1.5 inline-block rounded-xs bg-chip px-2 py-1 text-[11px] font-semibold text-heading">
                          {f.chip}
                        </span>
                      </span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 border-t border-border bg-card px-6 py-4">
        <div className="flex w-full items-center justify-between">
          {step > 0 ? (
            <button
              onClick={() => setStep((s) => s - 1)}
              className="rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
            >
              Back
            </button>
          ) : (
            <Link
              to="/attendance"
              className="rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
            >
              Back
            </Link>
          )}
          <button
            disabled={!canContinue}
            onClick={() => {
              if (step === 0) return setStep(1);
              attendanceActions.setTemplateFrequency(freq);
              navigate({ to: "/attendance/upload" });
            }}
            className="rounded-md bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {step === 1 ? "Generate Template" : "Next"}
          </button>
        </div>
      </footer>

    </AppShell>
  );
}
