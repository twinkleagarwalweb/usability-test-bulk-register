import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, Check, ChevronDown, ChevronLeft, Download, Search } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";
import {
  attendanceActions,
  selectRegisters,
  useAttendanceStore,
  type Register,
} from "@/lib/attendance-store";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export const Route = createFileRoute("/attendance/registers/")({
  head: () => ({
    meta: [
      { title: "Manage Register | City Municipal Corporation" },
      {
        name: "description",
        content:
          "View and manage all the generated attendance registers for this campaign.",
      },
      { property: "og:title", content: "Manage Register | City Municipal Corporation" },
      {
        property: "og:description",
        content:
          "View and manage all the generated attendance registers for this campaign.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GeneratedRegistersPage,
});

// A register matches a boundary level when that level is part of its hierarchy.
const hasBoundaryLevel = (r: Register, level: string) =>
  r.boundary.split(",").some((b) => b.trim() === level);

function Checkbox({ checked }: { checked: boolean }) {
  return (
    <span
      className={`flex size-4 shrink-0 items-center justify-center rounded-xs border ${
        checked ? "border-primary bg-primary text-primary-foreground" : "border-input bg-card"
      }`}
    >
      {checked && <Check className="size-3" strokeWidth={3} />}
    </span>
  );
}

function GeneratedRegistersPage() {
  const [registerId, setRegisterId] = useState("");
  const [officer, setOfficer] = useState("");
  const [boundary, setBoundary] = useState("");
  const store = useAttendanceStore();
  const registers = useMemo(() => selectRegisters(store), [store]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const filtered = useMemo(
    () =>
      registers.filter(
        (r) =>
          (!registerId || r.id === registerId) &&
          (!officer || r.officer === officer) &&
          (!boundary || hasBoundaryLevel(r, boundary)),
      ),
    [registers, registerId, officer, boundary],
  );

  // Drop selections that are hidden by the filters so bulk actions only touch visible rows.
  useEffect(() => {
    const visible = new Set(filtered.map((r) => r.id));
    setSelectedIds((prev) => {
      const next = new Set([...prev].filter((id) => visible.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [filtered]);

  const allSelected = filtered.length > 0 && filtered.every((r) => selectedIds.has(r.id));

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filtered.map((r) => r.id)));
    }
  };

  const handleBulkDelete = () => {
    const remaining = registers.filter((r) => !selectedIds.has(r.id));
    attendanceActions.deleteRegisters([...selectedIds]);
    // Reset filters whose option no longer exists after the delete.
    if (selectedIds.has(registerId)) setRegisterId("");
    if (officer && !remaining.some((r) => r.officer === officer)) setOfficer("");
    setSelectedIds(new Set());
  };

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-28 pt-4">
        <div className="w-full">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: "Manage Register" },
            ]}
          />

          <div className="mt-4 rounded-lg border border-border bg-card px-6 py-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h1 className="font-condensed text-3xl font-bold text-heading">
                  Manage Register
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  View and manage all the generated attendance registers for this campaign.
                </p>
              </div>
            </div>

            <div className="mt-5 flex flex-wrap items-end gap-4">
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">Register Name</label>
                <div className="relative mt-1">
                  <select
                    value={registerId}
                    onChange={(e) => setRegisterId(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {registers.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">
                  Attendance officer
                </label>
                <div className="relative mt-1">
                  <select
                    value={officer}
                    onChange={(e) => setOfficer(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {Array.from(new Set(registers.map((r) => r.officer).filter(Boolean))).map((o) => (
                      <option key={o} value={o}>
                        {o}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">Boundary Level</label>
                <div className="relative mt-1">
                  <select
                    value={boundary}
                    onChange={(e) => setBoundary(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {["State", "LGA", "Ward", "Settlement"].map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="ml-auto flex items-center gap-4">
                <button
                  onClick={() => {
                    setRegisterId("");
                    setOfficer("");
                    setBoundary("");
                  }}
                  className="text-sm font-medium text-primary hover:underline"
                >
                  Clear Search
                </button>
                <button className="flex items-center gap-2 rounded-md bg-primary px-5 py-2 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95">
                  <Search className="size-4" /> Search
                </button>
              </div>
            </div>
          </div>

          <div className="mt-4 overflow-hidden rounded-lg border border-border bg-card p-4">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-3">
                <h2 className="text-xl font-bold text-heading">Generated Registers</h2>
                {selectedIds.size > 0 && (
                  <span className="rounded-xs bg-info px-2 py-0.5 text-[11px] font-semibold text-info-foreground">
                    {selectedIds.size} {selectedIds.size === 1 ? "register" : "registers"} selected
                  </span>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  disabled={selectedIds.size === 0}
                  className="flex items-center gap-2 whitespace-nowrap rounded-md border border-primary bg-white px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5 disabled:cursor-not-allowed disabled:border-border disabled:text-muted-foreground disabled:hover:bg-transparent"
                >
                  Delete Register
                </button>
                <button
                  disabled={selectedIds.size === 0}
                  className="flex items-center gap-2 whitespace-nowrap rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground"
                >
                  <Download className="size-4" /> Download Register
                </button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] border-collapse text-left">
                <thead>
                  <tr className="bg-muted">
                    {[
                      { label: "__select", width: "w-14" },
                      "Register Name",
                      { label: "Number of Users", align: "right" },
                      { label: "Boundary Level", width: "min-w-[220px]" },
                      "Attendance Frequency",
                      "Attendance Officer",
                    ].map((h, i, arr) => {
                      const label = typeof h === "string" ? h : h.label;
                      const align = typeof h === "string" ? "left" : h.align;
                      const width = typeof h === "object" && "width" in h ? h.width : "";
                      return (
                        <th
                          key={label}
                          className={`px-4 py-3 text-xs font-bold text-heading ${
                            align === "right" ? "text-right" : "text-left"
                          } ${width} ${i === 0 ? "rounded-l-md" : ""} ${
                            i === arr.length - 1 ? "rounded-r-md" : ""
                          }`}
                        >
                          {label === "__select" ? (
                            <button
                              aria-label="Select all registers"
                              onClick={toggleSelectAll}
                            >
                              <Checkbox checked={allSelected} />
                            </button>
                          ) : (
                            label
                          )}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-4 py-8 text-center text-sm text-muted-foreground">
                        No registers match the selected filters.
                      </td>
                    </tr>
                  )}
                  {filtered.map((r) => {
                    const isChecked = selectedIds.has(r.id);
                    return (
                      <tr
                        key={r.id}
                        onClick={() => toggleSelect(r.id)}
                        className={`cursor-pointer border-b border-border last:border-0 transition-colors ${
                          isChecked ? "bg-selected-bg" : "hover:bg-muted/40"
                        }`}
                      >
                        <td className="px-4 py-3">
                          <Checkbox checked={isChecked} />
                        </td>
                        <td className="px-4 py-3 text-sm font-medium text-primary underline">
                          <Link
                            to="/attendance/registers/$registerId"
                            params={{ registerId: r.id }}
                            search={{ from: "manage" }}
                            onClick={(e) => e.stopPropagation()}
                          >
                            {r.name}
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-right text-sm tabular-nums text-foreground">
                          {r.users}
                        </td>
                        <td className="min-w-[260px] whitespace-normal break-words px-4 py-3 text-sm text-foreground">
                          {r.boundary}
                        </td>
                        <td className="px-4 py-3 text-sm text-foreground">{r.frequency}</td>
                        <td className="px-4 py-3 text-sm text-foreground">{r.officer || "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 border-t border-border bg-card px-6 py-4">
        <div className="flex w-full items-center">
          <Link
            to="/attendance"
            className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
          >
            <ChevronLeft className="size-4" /> Back
          </Link>
        </div>
      </footer>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent className="max-w-md bg-white">
          <AlertDialogHeader className="items-center text-center">
            <div className="flex size-12 items-center justify-center rounded-full bg-red-50">
              <AlertTriangle className="size-6 text-red-600" />
            </div>
            <AlertDialogTitle className="text-xl font-bold text-heading">
              Are you sure you want to delete these registers?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-sm text-foreground">
              You've selected {selectedIds.size} {selectedIds.size === 1 ? "register" : "registers"}. Once deleted, they cannot be recovered.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="grid grid-cols-2 gap-3 sm:space-x-0">
            <AlertDialogCancel
              onClick={() => setShowDeleteConfirm(false)}
              className="w-full rounded-md border border-primary bg-white px-5 py-2.5 text-sm font-medium text-primary hover:bg-primary/5"
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                handleBulkDelete();
                setShowDeleteConfirm(false);
              }}
              className="w-full rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:brightness-95"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppShell>
  );
}
