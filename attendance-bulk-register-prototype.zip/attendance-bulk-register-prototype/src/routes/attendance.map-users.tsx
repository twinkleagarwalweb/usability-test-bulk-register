import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Check, ChevronDown, ChevronLeft, Search } from "lucide-react";
import { AppShell, Breadcrumb } from "@/components/app-shell";
import {
  attendanceActions,
  getAttendanceState,
  selectRegisters,
  useAttendanceStore,
  type Register,
} from "@/lib/attendance-store";

export const Route = createFileRoute("/attendance/map-users")({
  head: () => ({
    meta: [
      { title: "Select Attendance Registers to Map Users | City Municipal Corporation" },
      {
        name: "description",
        content:
          "Choose the attendance registers where you want to map users and assign them to teams.",
      },
      {
        property: "og:title",
        content: "Select Attendance Registers to Map Users | City Municipal Corporation",
      },
      {
        property: "og:description",
        content:
          "Choose the attendance registers where you want to map users and assign them to teams.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MapUsersPage,
});

// A register matches a boundary level when that level is part of its hierarchy.
const hasBoundaryLevel = (r: Register, level: string) =>
  r.boundary.split(",").some((b) => b.trim() === level);

function Checkbox({ checked }: { checked: boolean }) {
  return (
    <span
      className={`flex size-4 shrink-0 items-center justify-center rounded-xs border ${
        checked ? "border-primary bg-primary text-primary-foreground" : "border-input bg-card"
      }`}
    >
      {checked && <Check className="size-3" strokeWidth={3} />}
    </span>
  );
}

function MapUsersPage() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/attendance/map-users" }) as { preselect?: string };
  const store = useAttendanceStore();
  const registers = useMemo(() => selectRegisters(store), [store]);
  const [selected, setSelected] = useState<string[]>([]);

  // Coming from the register upload success screen: preselect the registers just
  // uploaded (or all registers if none were uploaded). Runs after hydration so
  // stored registers are available.
  useEffect(() => {
    if (search.preselect !== "latest") return;
    const all = selectRegisters(getAttendanceState()).map((r) => r.id);
    const latest = getAttendanceState().latestIds.filter((id) => all.includes(id));
    setSelected(latest.length ? latest : all);
  }, [search.preselect]);
  const [registerId, setRegisterId] = useState("");
  const [officer, setOfficer] = useState("");
  const [boundary, setBoundary] = useState("");

  const toggle = (id: string) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const filtered = useMemo(() => {
    const officerQuery = officer.trim().toLowerCase();
    return registers.filter(
      (r) =>
        (!registerId || r.id === registerId) &&
        (!officerQuery || r.officer.toLowerCase().includes(officerQuery)) &&
        (!boundary || hasBoundaryLevel(r, boundary)),
    );
  }, [registers, registerId, officer, boundary]);

  // Drop selections that are hidden by the filters so Proceed only uses visible rows.
  useEffect(() => {
    // Nothing is hidden without filters; skipping also keeps the preselection intact on hydration.
    if (!registerId && !officer.trim() && !boundary) return;
    const visible = new Set(filtered.map((r) => r.id));
    setSelected((s) => {
      const next = s.filter((id) => visible.has(id));
      return next.length === s.length ? s : next;
    });
  }, [filtered]);

  const allSelected = filtered.length > 0 && filtered.every((r) => selected.includes(r.id));

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-28 pt-4">
        <div className="w-full">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: "Select Attendance Registers to Map Users" },
            ]}
          />

          <div className="mt-4 rounded-lg border border-border bg-card px-6 py-5">
            <span className="inline-block rounded-xs bg-chip px-2 py-1 text-[11px] font-semibold text-heading">
              Moz_ Tete_Bednet_Malaria (2026)
            </span>
            <h1 className="mt-3 font-condensed text-3xl font-bold text-heading">
              Select attendance registers to map users
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Choose the register where you want to map users and assign them to teams.
            </p>

            <div className="mt-5 flex flex-wrap items-end gap-4">
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">Register Name</label>
                <div className="relative mt-1">
                  <select
                    value={registerId}
                    onChange={(e) => setRegisterId(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {registers.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">
                  Attendance officer
                </label>
                <input
                  value={officer}
                  onChange={(e) => setOfficer(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                />
              </div>
              <div className="w-56">
                <label className="block text-sm font-medium text-foreground">Boundary Level</label>
                <div className="relative mt-1">
                  <select
                    value={boundary}
                    onChange={(e) => setBoundary(e.target.value)}
                    className="w-full appearance-none rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground"
                  >
                    <option value="">Select</option>
                    {["State", "LGA", "Ward", "Settlement"].map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-3 size-4 text-muted-foreground" />
                </div>
              </div>
              <div className="ml-auto flex items-center gap-4">
                <button
                  onClick={() => {
                    setRegisterId("");
                    setOfficer("");
                    setBoundary("");
                  }}
                  className="text-sm font-medium text-primary hover:underline"
                >
                  Clear Search
                </button>
                <button className="flex items-center gap-2 rounded-md bg-primary px-5 py-2 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95">
                  <Search className="size-4" /> Search
                </button>
              </div>
            </div>
          </div>

          <div className="mt-4 overflow-hidden rounded-lg border border-border bg-card p-4">
            {selected.length > 0 && (
              <div className="mb-3 inline-flex rounded-xs bg-info px-2 py-1 text-xs font-semibold text-info-foreground">
                {selected.length} {selected.length === 1 ? "register" : "registers"} selected
              </div>
            )}
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] border-collapse text-left">
                <thead>
                  <tr className="bg-muted">
                    <th className="w-10 rounded-l-md px-4 py-3">
                      <button
                        aria-label="Select all registers"
                        onClick={() =>
                          setSelected(allSelected ? [] : filtered.map((r) => r.id))
                        }
                      >
                        <Checkbox checked={allSelected} />
                      </button>
                    </th>
                    {[
                      "Register Name",
                      { label: "Number of Users", align: "right" },
                      "Boundary Level",
                      "Attendance Frequency",
                      "Attendance Officer",
                    ].map((h, i, arr) => {
                      const label = typeof h === "string" ? h : h.label;
                      const align = typeof h === "string" ? "left" : h.align;
                      return (
                        <th
                          key={label}
                          className={`px-4 py-3 text-xs font-bold text-heading ${
                            align === "right" ? "text-right" : "text-left"
                          } ${i === arr.length - 1 ? "rounded-r-md" : ""}`}
                        >
                          {label}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-4 py-8 text-center text-sm text-muted-foreground">
                        No registers match the selected filters.
                      </td>
                    </tr>
                  )}
                  {filtered.map((r) => {
                    const isChecked = selected.includes(r.id);
                    return (
                      <tr
                        key={r.id}
                        onClick={() => toggle(r.id)}
                        className={`cursor-pointer border-b border-border last:border-0 transition-colors ${
                          isChecked ? "bg-selected-bg" : "hover:bg-muted/40"
                        }`}
                      >
                        <td className="px-4 py-3">
                          <Checkbox checked={isChecked} />
                        </td>
                        <td className="px-4 py-3 text-sm font-medium text-primary underline">
                          <Link
                            to="/attendance/registers/$registerId"
                            params={{ registerId: r.id }}
                            search={{ from: "map-users" }}
                            onClick={(e) => e.stopPropagation()}
                          >
                            {r.name}
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-right text-sm text-foreground tabular-nums">{r.users}</td>
                        <td className="px-4 py-3 text-sm text-foreground">{r.boundary}</td>
                        <td className="px-4 py-3 text-sm text-foreground">{r.frequency}</td>
                        <td className="px-4 py-3 text-sm text-foreground">{r.officer || "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 border-t border-border bg-card px-6 py-4">
        <div className="flex w-full items-center justify-between">
          <Link
            to="/attendance/upload"
            className="flex items-center gap-1.5 rounded-md border border-primary px-5 py-2.5 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
          >
            <ChevronLeft className="size-4" /> Back
          </Link>
          <button
            disabled={selected.length === 0}
            onClick={() => {
              attendanceActions.setMappingRegisters(selected);
              navigate({ to: "/attendance/map-template" });
            }}
            className="rounded-md bg-primary px-8 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Proceed
          </button>
        </div>
      </footer>
    </AppShell>
  );
}
