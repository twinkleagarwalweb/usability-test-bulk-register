import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/attendance/registers")({
  component: RegistersLayout,
});

function RegistersLayout() {
  return <Outlet />;
}
