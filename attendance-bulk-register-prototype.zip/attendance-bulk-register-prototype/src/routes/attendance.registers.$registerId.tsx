import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { z } from "zod";
import arrowBack from "@/assets/view-register/arrow-back.svg";
import arrowDropDown from "@/assets/view-register/arrow-drop-down.svg";
import arrowDropDownGrey from "@/assets/view-register/arrow-drop-down-grey.svg";
import arrowForwardIos from "@/assets/view-register/arrow-forward-ios.svg";
import checkCircleOutline from "@/assets/view-register/check-circle-outline.svg";
import chevronLeft from "@/assets/view-register/chevron-left.svg";
import chevronRight from "@/assets/view-register/chevron-right.svg";
import editIcon from "@/assets/view-register/edit.svg";
import firstPage from "@/assets/view-register/first-page.svg";
import lastPage from "@/assets/view-register/last-page.svg";
import emptyRegisterArt from "@/assets/empty-attendance-register.png";
import { AppShell, Breadcrumb } from "@/components/app-shell";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  attendanceActions,
  selectRegisters,
  useAttendanceStore,
  type Register,
  type RegisterUser,
} from "@/lib/attendance-store";
import { downloadReport } from "@/lib/templates";

// Where the register was opened from, for the breadcrumb and Back button.
const ORIGINS = {
  manage: { label: "Manage Register", to: "/attendance/registers" },
  "map-users": { label: "Select Attendance Registers to Map Users", to: "/attendance/map-users" },
  "audit-log": { label: "Audit Log", to: "/attendance/audit-log" },
} as const;

export const Route = createFileRoute("/attendance/registers/$registerId")({
  validateSearch: z.object({
    from: z.enum(["manage", "map-users", "audit-log"]).optional().catch(undefined),
  }),
  head: () => ({
    meta: [
      { title: "View Register | City Municipal Corporation" },
      {
        name: "description",
        content: "View attendance details and worker performance for this attendance register.",
      },
      { property: "og:title", content: "View Register | City Municipal Corporation" },
      {
        property: "og:description",
        content: "View attendance details and worker performance for this attendance register.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ViewRegisterPage,
});

/* ---------- Sample attendance data ---------- */

const CAMPAIGN = { name: "Campaign Name 1", dates: "21 August - 30 August, 2025" };

const ATTENDANCE_DAYS = ["21/08/2025", "22/08/2025", "23/08/2025", "24/08/2025", "25/08/2025"];
const UNMARKED_INDEX = 4; // 25 August has no attendance marked
const TARGET_PER_DAY = 70;

type Status = RegisterUser["status"];

type Worker = {
  id: string;
  name: string;
  role: string;
  teamCode: string;
  status: Status;
  /** Present / absent per attendance day (unmarked days are null). */
  days: (boolean | null)[];
  performance: number;
};

function hash(text: string) {
  let h = 0;
  for (const ch of text) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return h;
}

/** Deterministic dummy attendance so each register always shows the same numbers. */
function withAttendance(base: Omit<Worker, "days" | "performance">): Worker {
  const seed = hash(base.id);
  const days = ATTENDANCE_DAYS.map((_, i) =>
    i === UNMARKED_INDEX ? null : base.status === "Active" || (seed >> i) % 2 === 0,
  );
  const worked = days.filter(Boolean).length;
  return { ...base, days, performance: worked * (40 + (seed % 30)) };
}

/** Users mapped to this register via the attendee template (none until users are mapped). */
function workersFor(registerId: string, users: RegisterUser[]): Worker[] {
  return users
    .filter((u) => u.registerId === registerId)
    .map((u) =>
      withAttendance({
        id: u.id,
        name: u.name,
        role: u.role,
        teamCode: u.teamCode || "—",
        status: u.status,
      }),
    );
}

const daysWorked = (w: Worker) => w.days.filter(Boolean).length;

/* ---------- Page ---------- */

const PAGE_SIZES = [5, 10, 20];

function StatusChip({ status }: { status: Status }) {
  return (
    <span
      className={`inline-flex rounded-md px-3 py-1 text-sm leading-[1.37] ${
        status === "Active" ? "bg-[#f1fff8] text-[#00703c]" : "bg-[#fff5f4] text-[#b91900]"
      }`}
    >
      {status}
    </span>
  );
}

function DetailRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex flex-col gap-1 text-base sm:flex-row sm:items-center sm:gap-16">
      <dt className="font-bold leading-[1.14] text-foreground sm:w-[250px] sm:shrink-0">{label}</dt>
      <dd className="leading-[1.37] text-muted-foreground">{value}</dd>
    </div>
  );
}

function reportDownloads(register: Register | undefined, registerName: string, workers: Worker[]) {
  const base = (w: Worker) => [w.name, w.role, w.teamCode, w.status];
  const file = registerName.replace(/[^\w-]+/g, "_");
  const header = ["Worker Name", "Role", "Team Code", "Status"];
  const audit = (report: string) => ({
    action: "Register Downloaded",
    register: register?.name ?? registerName,
    details: `${report} downloaded · ${workers.length} ${workers.length === 1 ? "user" : "users"}`,
  });
  return [
    {
      label: "Download Attendance Report",
      run: () =>
        downloadReport(
          `${file}_Attendance_Report.xlsx`,
          "Attendance Report",
          [...header, ...ATTENDANCE_DAYS, "Days Worked", "Performance"],
          workers.map((w) => [
            ...base(w),
            ...w.days.map((d) => (d === null ? "Not marked" : d ? "Present" : "Absent")),
            daysWorked(w),
            w.performance,
          ]),
          audit("Attendance report"),
        ),
    },
    {
      label: "Download Signature List",
      run: () =>
        downloadReport(
          `${file}_Signature_List.xlsx`,
          "Signature List",
          [...header, "Register ID", "Days Worked", "Signature"],
          workers.map((w) => [...base(w), register?.name ?? registerName, daysWorked(w), null]),
          audit("Signature list"),
        ),
    },
    {
      label: "Download Photo List",
      run: () =>
        downloadReport(
          `${file}_Photo_List.xlsx`,
          "Photo List",
          [...header, "Register ID", "Photo"],
          workers.map((w) => [...base(w), register?.name ?? registerName, null]),
          audit("Photo list"),
        ),
    },
  ];
}

function ViewRegisterPage() {
  const { registerId } = Route.useParams();
  const { from } = Route.useSearch();
  const navigate = useNavigate();
  const origin = ORIGINS[from ?? "manage"];
  const store = useAttendanceStore();
  const register = useMemo(
    () => selectRegisters(store).find((r) => r.id === registerId),
    [store, registerId],
  );
  const workers = useMemo(() => workersFor(registerId, store.users), [registerId, store.users]);

  const [showDetails, setShowDetails] = useState(false);
  const [pageSize, setPageSize] = useState(20);
  const [page, setPage] = useState(0);

  const pageCount = Math.max(1, Math.ceil(workers.length / pageSize));
  const current = Math.min(page, pageCount - 1);
  const visible = workers.slice(current * pageSize, (current + 1) * pageSize);
  const rangeStart = workers.length ? current * pageSize + 1 : 0;
  const rangeEnd = Math.min((current + 1) * pageSize, workers.length);

  const totalPerformance = workers.reduce((sum, w) => sum + w.performance, 0);
  const workingDays = ATTENDANCE_DAYS.length;
  const target =
    workers.filter((w) => w.status === "Active").length * workingDays * TARGET_PER_DAY || 1;
  const targetAchieved = Math.min(100, Math.round((totalPerformance / target) * 100));
  const registerName = register?.name ?? `ID-${registerId}`;
  const downloads = reportDownloads(register, registerName, workers);

  return (
    <AppShell>
      <main className="min-w-0 flex-1 bg-muted/40 px-6 pb-32 pt-6">
        <div className="flex w-full flex-col gap-6">
          <Breadcrumb
            items={[
              { label: "Home", to: "/" },
              { label: "Attendance Setup & Management", to: "/attendance" },
              { label: origin.label, to: origin.to },
              { label: "View Register" },
            ]}
          />
          <h1 className="font-condensed text-[40px] font-bold leading-[1.14] text-heading">
            View Register
          </h1>

          {/* Summary */}
          <div className="grid gap-6 rounded-xl bg-card px-6 py-6 text-center text-muted-foreground shadow-[0px_2px_3.5px_rgba(0,0,0,0.15)] sm:grid-cols-3 lg:px-[100px]">
            {[
              {
                value: totalPerformance.toLocaleString("en-US"),
                label: "Registrations/\nInterventions Completed",
              },
              { value: `${targetAchieved}%`, label: "Target Achieved" },
              { value: "1 Day", label: "with Unmarked\nAttendance" },
            ].map((s) => (
              <div key={s.label} className="flex flex-col items-center gap-0.5">
                <div className="text-2xl font-bold leading-[1.14]">{s.value}</div>
                <div className="whitespace-pre-line text-base leading-[1.37]">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Campaign, register and attendance details */}
          <div className="flex flex-col gap-6 rounded-xl bg-card p-6">
            <div className="flex flex-col gap-2">
              <h2 className="text-[28px] font-bold leading-[1.14] text-heading">{CAMPAIGN.name}</h2>
              <p className="text-xl font-medium leading-[1.14] text-[#787878]">{CAMPAIGN.dates}</p>
            </div>

            <div className="rounded-lg border border-[#d6d5d4] bg-info-bg">
              <button
                type="button"
                onClick={() => setShowDetails((s) => !s)}
                aria-expanded={showDetails}
                className="flex w-full items-start justify-between gap-4 p-6 text-left"
              >
                <span className="flex flex-col gap-1">
                  <span className="text-2xl font-bold leading-[1.14] text-heading">
                    Register Details
                  </span>
                  <span className="text-base leading-6 text-muted-foreground">
                    View register ID, officer, contact details, status, and timeline
                  </span>
                </span>
                <img
                  src={arrowForwardIos}
                  alt=""
                  width={24}
                  height={24}
                  className={`shrink-0 transition-transform ${showDetails ? "rotate-90" : ""}`}
                />
              </button>
              {showDetails && (
                <dl className="flex flex-col gap-4 border-t border-[#d6d5d4] p-6">
                  <DetailRow label="Register ID" value={registerName} />
                  <DetailRow label="Attendance Officer" value={register?.officer || "—"} />
                  <DetailRow label="Contact Details" value="+234 803 555 0142" />
                  <DetailRow label="Status" value={<StatusChip status="Active" />} />
                  <DetailRow
                    label="Boundary"
                    value={register?.boundaryName || register?.boundary || "—"}
                  />
                  <DetailRow label="Attendance Frequency" value={register?.frequency ?? "Once"} />
                  <DetailRow
                    label="Timeline"
                    value="Created 18 August 2025 · Attendance 21 August 2025 - 25 August 2025"
                  />
                </dl>
              )}
            </div>

            <div className="flex flex-wrap items-start justify-between gap-4 rounded-lg border border-[#d6d5d4] bg-info-bg p-6">
              <div className="flex flex-col gap-4">
                <h3 className="flex h-[34px] items-center text-2xl font-bold leading-[1.14] text-heading">
                  Attendance Details
                </h3>
                <dl className="flex flex-col gap-4">
                  <DetailRow label="Attendance Duration" value="21 August 2025 - 25 August 2025" />
                  <DetailRow
                    label="Original Duration (in days)"
                    value={`${ATTENDANCE_DAYS.length} Days`}
                  />
                  <DetailRow label="Days without Attendance Marked" value="1 Day" />
                </dl>
              </div>
              <div className="flex items-center gap-4">
                <DropdownMenu>
                  <DropdownMenuTrigger className="flex h-8 w-[172px] items-center justify-center gap-2 rounded-md border border-primary bg-white px-5 text-base font-medium leading-[1.14] text-primary transition-colors hover:bg-primary/5 data-[state=open]:bg-primary/5">
                    Download <img src={arrowDropDown} alt="" width={24} height={24} />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align="end"
                    className="w-[248px] overflow-hidden rounded-xl border-0 bg-white p-0 shadow-[0px_4px_6px_rgba(0,0,0,0.2)]"
                  >
                    {downloads.map((d) => (
                      <DropdownMenuItem
                        key={d.label}
                        onSelect={() => void d.run()}
                        className="cursor-pointer rounded-none px-2.5 py-4 text-base leading-6 text-[#0b0c0c] focus:bg-[#eee]"
                      >
                        {d.label}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>

          {/* Workers */}
          <div className="flex flex-col gap-6 rounded-xl bg-card p-6">
            <div className="flex flex-wrap items-center justify-between gap-6">
              <h2 className="text-[28px] font-bold leading-[1.14] text-heading">
                Worker Attendance &amp; Performance Register
              </h2>
              {workers.length > 0 && (
                <button className="flex h-8 items-center justify-center gap-2 rounded-md border border-primary bg-white px-6 text-base font-medium leading-[1.14] text-primary transition-colors hover:bg-primary/5">
                  <img src={editIcon} alt="" width={24} height={24} /> Edit Attendance
                </button>
              )}
            </div>

            {workers.length === 0 ? (
              <div className="flex flex-col items-center rounded-xl border border-[#c5c5c5] bg-card px-6 py-10 text-center">
                <img
                  src={emptyRegisterArt}
                  alt="Illustration of two workers carrying an attendance register"
                  className="h-44 w-auto object-contain"
                  loading="lazy"
                  width={1376}
                  height={768}
                />
                <h3 className="mt-4 text-2xl font-bold leading-[1.14] text-heading">
                  No users are mapped
                </h3>
                <p className="mt-2 max-w-md text-base leading-[1.37] text-muted-foreground">
                  Map users to this register to see their attendance and performance here.
                </p>
              </div>
            ) : (
              <div className="overflow-hidden rounded-xl border border-[#c5c5c5] bg-info-bg">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[1280px] border-collapse text-left">
                    <thead>
                      <tr className="border-b border-[#d6d5d4] bg-[#eee]">
                        {[
                          { label: "Worker Name", width: "w-[196px]" },
                          { label: "Role", width: "w-[180px]" },
                          { label: "Team Code", width: "w-[180px]" },
                          { label: "Status", width: "w-[180px]" },
                          { label: "Days Worked", width: "w-[180px]" },
                          {
                            label: "Performance (Registrations / Interventions)",
                            width: "min-w-[364px]",
                          },
                        ].map((h) => (
                          <th key={h.label} className={`py-4 pl-4 align-top ${h.width}`}>
                            <span className="flex justify-between gap-4 whitespace-nowrap pr-0 text-base font-bold leading-[1.14] text-heading">
                              {h.label}
                              <span className="w-px shrink-0 self-stretch bg-[#787878]" />
                            </span>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {visible.map((w) => (
                        <tr key={w.id} className="h-[74px] align-top">
                          <td className="p-4 text-base leading-[1.37] text-primary underline">
                            {w.name}
                          </td>
                          <td className="p-4 text-base leading-[1.37] text-foreground">{w.role}</td>
                          <td className="p-4 text-base leading-[1.37] text-foreground">
                            {w.teamCode}
                          </td>
                          <td className="p-4">
                            <StatusChip status={w.status} />
                          </td>
                          <td className="p-4 text-base leading-[1.37] tabular-nums text-foreground">
                            {daysWorked(w)}
                          </td>
                          <td className="p-4 text-base leading-[1.37] tabular-nums text-foreground">
                            {w.performance}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="flex h-[49px] items-center justify-end gap-[3px] border-t border-[#c5c5c5] px-6 text-base leading-6 text-muted-foreground">
                  <label className="flex items-center gap-2 p-2.5">
                    <span>Rows</span>
                    <span className="relative flex items-center">
                      <select
                        value={pageSize}
                        onChange={(e) => {
                          setPageSize(Number(e.target.value));
                          setPage(0);
                        }}
                        aria-label="Rows per page"
                        className="cursor-pointer appearance-none bg-transparent pr-6"
                      >
                        {PAGE_SIZES.map((n) => (
                          <option key={n} value={n}>
                            {n}
                          </option>
                        ))}
                      </select>
                      <img
                        src={arrowDropDownGrey}
                        alt=""
                        width={24}
                        height={24}
                        className="pointer-events-none absolute right-0"
                      />
                    </span>
                  </label>
                  <span className="p-2.5">
                    {rangeStart} - {rangeEnd} of {workers.length}
                  </span>
                  <div className="flex items-center gap-4">
                    {[
                      { icon: firstPage, label: "First page", to: 0, off: current === 0 },
                      {
                        icon: chevronLeft,
                        label: "Previous page",
                        to: current - 1,
                        off: current === 0,
                      },
                      {
                        icon: chevronRight,
                        label: "Next page",
                        to: current + 1,
                        off: current >= pageCount - 1,
                      },
                      {
                        icon: lastPage,
                        label: "Last page",
                        to: pageCount - 1,
                        off: current >= pageCount - 1,
                      },
                    ].map(({ icon, label, to, off }) => (
                      <button
                        key={label}
                        aria-label={label}
                        disabled={off}
                        onClick={() => setPage(to)}
                        className="rounded-sm transition-opacity hover:opacity-70 disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        <img src={icon} alt="" width={24} height={24} />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-11 right-0 z-30 flex h-[72px] items-center rounded-t-xl bg-card px-8 shadow-[0px_-1px_1px_rgba(0,0,0,0.16)]">
        <div className="flex w-full items-center justify-between gap-4">
          <Link
            to={origin.to}
            className="flex h-10 w-[237px] items-center justify-center gap-2 rounded-md border border-primary bg-white px-6 text-xl font-medium leading-[1.14] text-primary transition-colors hover:bg-primary/5"
          >
            <img src={arrowBack} alt="" width={24} height={24} /> Back
          </Link>
          <button
            onClick={() => {
              // Map users to this register: continue the mapping flow with it selected.
              attendanceActions.setMappingRegisters([registerId]);
              navigate({ to: "/attendance/map-template" });
            }}
            className="flex h-10 w-[271px] items-center justify-center gap-2 rounded-md bg-primary px-6 text-xl font-medium leading-[1.14] text-primary-foreground transition-colors hover:brightness-95"
          >
            <img src={checkCircleOutline} alt="" width={24} height={24} /> Map Users
          </button>
        </div>
      </footer>
    </AppShell>
  );
}
