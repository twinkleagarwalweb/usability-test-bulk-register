import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { colLetter, downloadWorkbook, type Cell, type Workbook } from "@/lib/templates";

// Read-only, spreadsheet-style preview of a generated template: column letters,
// row numbers, frozen header rows and sheet tabs, mirroring what Excel shows
// (the hidden code row and hidden columns stay hidden).

const MIN_ROWS = 12;

function cellValue(cell: Cell): unknown {
  return cell !== null && typeof cell === "object" && !(cell instanceof Date) && "value" in cell
    ? cell.value
    : cell;
}

function formatCell(cell: Cell) {
  const value = cellValue(cell);
  if (value == null) return "";
  if (value instanceof Date) {
    const d = String(value.getUTCDate()).padStart(2, "0");
    const m = String(value.getUTCMonth() + 1).padStart(2, "0");
    return `${d}/${m}/${value.getUTCFullYear()}`;
  }
  return String(value);
}

export function TemplatePreviewDialog({
  workbook,
  title,
  onClose,
}: {
  workbook: Workbook | null;
  title: string;
  onClose: () => void;
}) {
  const [active, setActive] = useState(0);
  // Open on the first sheet with data (e.g. skip the Instructions sheet).
  useEffect(() => {
    setActive(Math.max(0, workbook?.sheets.findIndex((s) => s.rows.length) ?? 0));
  }, [workbook]);

  const sheet = workbook?.sheets[active];
  const columns = sheet
    ? sheet.columns.map((c, index) => ({ ...c, index })).filter((c) => !c.hidden)
    : [];
  const rows = sheet?.rows ?? [];
  const blankRows = Math.max(MIN_ROWS - rows.length, 3);

  return (
    <Dialog open={!!workbook} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="flex max-h-[85vh] max-w-[min(72rem,calc(100vw-3rem))] flex-col gap-0 overflow-hidden bg-white p-0">
        <DialogHeader className="border-b border-border px-6 py-4 pr-12">
          <DialogTitle className="text-xl font-bold text-heading">{title}</DialogTitle>
          <DialogDescription className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <span className="flex size-6 items-center justify-center rounded-sm bg-green-700 text-[8px] font-bold text-white">
              .xlsx
            </span>
            <span className="font-bold text-heading">{workbook?.fileName}</span>
            <span>· Preview of the generated template with sample data.</span>
          </DialogDescription>
        </DialogHeader>

        {sheet && (
          <div className="min-h-0 flex-1 overflow-auto bg-card">
            <table className="min-w-full border-separate border-spacing-0 text-xs text-foreground">
              <thead className="sticky top-0 z-20">
                <tr>
                  <th className="sticky left-0 z-30 w-10 min-w-10 border-b border-r border-border bg-muted" />
                  {columns.map((c) => (
                    <th
                      key={c.code}
                      className="border-b border-r border-border bg-muted px-2 py-1 text-center font-medium text-muted-foreground"
                    >
                      {colLetter(c.index)}
                    </th>
                  ))}
                  <th className="w-full border-b border-border bg-muted" />
                </tr>
                {/* Row 2: column labels (row 1, the system codes, is hidden like in Excel). */}
                <tr>
                  <th className="sticky left-0 z-30 border-b border-r border-border bg-muted px-2 py-1.5 text-center font-medium text-muted-foreground">
                    2
                  </th>
                  {columns.map((c) => (
                    <th
                      key={c.code}
                      style={{ minWidth: c.wrap ? 560 : Math.min(c.width ?? 20, 32) * 6 }}
                      className={`border-b-2 border-r border-b-muted-foreground/40 border-r-border bg-selected-bg px-2 py-1.5 text-left align-top font-bold text-heading ${
                        c.wrap ? "whitespace-pre-wrap font-normal leading-relaxed" : "whitespace-nowrap"
                      }`}
                    >
                      {c.label}
                    </th>
                  ))}
                  <th className="border-b-2 border-b-muted-foreground/40 bg-card" />
                </tr>
              </thead>
              <tbody>
                {rows.map((row, r) => (
                  <tr key={r}>
                    <td className="sticky left-0 z-10 border-b border-r border-border bg-muted px-2 py-1.5 text-center text-muted-foreground">
                      {r + 3}
                    </td>
                    {columns.map((c) => {
                      const cell = row[c.index] ?? null;
                      const numeric = typeof cellValue(cell) === "number";
                      return (
                        <td
                          key={c.code}
                          className={`whitespace-nowrap border-b border-r border-border px-2 py-1.5 ${
                            numeric ? "text-right tabular-nums" : ""
                          }`}
                        >
                          {formatCell(cell)}
                        </td>
                      );
                    })}
                    <td className="border-b border-border" />
                  </tr>
                ))}
                {Array.from({ length: blankRows }, (_, b) => (
                  <tr key={`blank-${b}`}>
                    <td className="sticky left-0 z-10 border-b border-r border-border bg-muted px-2 py-1.5 text-center text-muted-foreground">
                      {rows.length + b + 3}
                    </td>
                    {columns.map((c) => (
                      <td key={c.code} className="border-b border-r border-border px-2 py-1.5">
                        &nbsp;
                      </td>
                    ))}
                    <td className="border-b border-border" />
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Sheet tabs, as in Excel */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border bg-muted px-4 py-2">
          <div role="tablist" aria-label="Sheets" className="flex flex-wrap items-center gap-1">
            {workbook?.sheets.map((s, i) => (
              <button
                key={s.name}
                role="tab"
                aria-selected={i === active}
                onClick={() => setActive(i)}
                className={`rounded-md border px-3 py-1.5 text-xs font-medium transition-colors ${
                  i === active
                    ? "border-primary bg-card text-primary"
                    : "border-transparent text-muted-foreground hover:bg-card hover:text-foreground"
                }`}
              >
                {s.name}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="rounded-md border border-primary bg-white px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary/5"
            >
              Close
            </button>
            <button
              onClick={() => workbook && void downloadWorkbook(workbook)}
              className="flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:brightness-95"
            >
              <Download className="size-4" /> Download Generated Template
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
