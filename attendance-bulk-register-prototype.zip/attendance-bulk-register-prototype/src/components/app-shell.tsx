import { Link } from "@tanstack/react-router";
import {
  Search,
  Home,
  Copy,
  LayoutGrid,
  FileText,
  BookOpen,
  ChevronDown,
  CircleHelp,
  History as HistoryIcon,
  type LucideIcon,
} from "lucide-react";
import type { ReactNode } from "react";

const railItems = [Search, Home, Copy, LayoutGrid, FileText, BookOpen];

export function AppRail({ activeIndex = 1 }: { activeIndex?: number }) {
  return (
    <nav className="flex w-11 shrink-0 flex-col items-center gap-1 border-r border-border bg-rail py-3">
      {railItems.map((Icon, i) => (
        <button
          key={i}
          aria-label="Navigation item"
          className={`flex size-8 items-center justify-center rounded-sm transition-colors ${
            i === activeIndex
              ? "bg-primary text-primary-foreground"
              : "text-heading hover:bg-secondary"
          }`}
        >
          <Icon className="size-4" />
        </button>
      ))}
    </nav>
  );
}

export function Breadcrumb({ items }: { items: Array<{ label: string; to?: string }> }) {
  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs">
      {items.map((item, i) => {
        const isLast = i === items.length - 1;
        return (
          <span key={item.label} className="flex items-center gap-1.5">
            {i > 0 && <span className="text-muted-foreground">/</span>}
            {item.to && !isLast ? (
              <Link to={item.to} className="text-primary hover:underline">
                {item.label}
              </Link>
            ) : (
              <span className="text-muted-foreground">{item.label}</span>
            )}
          </span>
        );
      })}
    </nav>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-background font-sans text-foreground">
      <div className="h-1 w-full bg-accent" />
      <header className="flex h-14 items-center justify-between border-b border-border bg-topbar px-4">
        <div className="flex items-center gap-3">
          <div className="flex size-8 items-center justify-center rounded-full bg-muted text-[10px] font-bold text-accent">
            CMC
          </div>
          <Link
            to="/"
            className="text-[15px] font-bold tracking-tight text-foreground hover:opacity-80"
          >
            City Municipal Corporation
          </Link>
        </div>
        <div className="flex items-center gap-5 text-sm text-muted-foreground">
          <button className="flex items-center gap-1 transition-colors hover:text-foreground">
            City <ChevronDown className="size-3.5" />
          </button>
          <button className="flex items-center gap-1 transition-colors hover:text-foreground">
            English <ChevronDown className="size-3.5" />
          </button>
          <div className="flex size-7 items-center justify-center rounded-full bg-accent text-xs font-medium text-accent-foreground">
            A
          </div>
          <span className="text-sm font-semibold text-heading">DIGIT</span>
        </div>
      </header>
      <div className="flex flex-1">
        <AppRail />
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center justify-end gap-4 border-b border-border bg-secondary px-6 py-2.5">
            <button className="flex items-center gap-1.5 text-sm font-medium text-primary underline hover:no-underline">
              <CircleHelp className="size-4.5" /> Help
            </button>
            <Link
              to="/attendance/audit-log"
              className="flex items-center gap-1.5 rounded-md border border-primary bg-white px-3 py-1.5 text-sm font-medium text-primary hover:bg-secondary/50"
            >
              <HistoryIcon className="size-4" /> Audit Log
            </Link>
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}

export type { LucideIcon };
